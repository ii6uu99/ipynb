https://github.wuyanzheshui.workers.dev/istepanov/docker-backup-to-git



# istepanov /备份到git

[![码头之星](https://camo.githubusercontent.com/bc0539a0de783ddb8874ae0e84f98bce635dd0af/68747470733a2f2f696d672e736869656c64732e696f2f646f636b65722f73746172732f6973746570616e6f762f6261636b75702d746f2d6769742e737667)](https://hub.docker.com/r/istepanov/backup-to-git/) [![Docker拉](https://camo.githubusercontent.com/ca97bec3c0ae7100051d8162bb5f39502644142a/68747470733a2f2f696d672e736869656c64732e696f2f646f636b65722f70756c6c732f6973746570616e6f762f6261636b75702d746f2d6769742e737667)](https://hub.docker.com/r/istepanov/backup-to-git/) [![Docker构建](https://camo.githubusercontent.com/cc7110f081926aa5fee8d5e25063e35005bd0e4d/68747470733a2f2f696d672e736869656c64732e696f2f646f636b65722f6175746f6d617465642f6973746570616e6f762f6261636b75702d746f2d6769742e737667)](https://hub.docker.com/r/istepanov/backup-to-git/) [![层数](https://camo.githubusercontent.com/1259de4bc021277ba24ba0a9801ace0ed88e855a/68747470733a2f2f696d616765732e6d6963726f6261646765722e636f6d2f6261646765732f696d6167652f6973746570616e6f762f6261636b75702d746f2d6769742e737667)](https://microbadger.com/images/istepanov/backup-to-git)

定期将文件备份到远程git存储库的Docker容器。

### 用法

```
docker run -d [OPTIONS] istepanov/backup-to-git [no-cron]
```

### 必填参数：

- `-e GIT_NAME='Backup User'`：git用户名。
- `-e GIT_EMAIL='backup_user@example.com'`：git用户电子邮件。
- `-e GIT_URL=https://username:password@example.com/path`：git远程仓库。
- `-v /path/to/target/folder:/target:ro`：将目标本地文件夹安装到容器的数据文件夹。该文件夹的内容将被推送到git repo中。

### 可选参数：

- `-e 'CRON_SCHEDULE=0 1 * * *'`：指定cron作业何时开始（[详细信息](https://en.wikipedia.org/wiki/Cron)）。默认值为`0 1 * * *`（每天凌晨1:00运行）。
- `-e GIT_BRANCH=branch_name`：将提交提交到的git分支（默认为'master'）。
- `-e GIT_COMMIT_MESSAGE='Custom message'`：自定义提交消息（默认为“自动备份”）。
- `-e TARGET_FOLDER=/target`：容器内的目标文件夹（默认为'/ target'）。

### 命令：

- `no-cron`：如果指定，运行一次容器并退出（不进行cron调度）。

### 例子：

备份每分钟更改为git：

```
docker run -d \
    -v GIT_NAME: 'Backup User' \
    -v GIT_EMAIL: 'backup_user@example.com' \
    -v GIT_URL: https://username:password@bitbucket.org/username/repo.git
    -v  CRON_SCHEDULE: '* * * * *'
    -v /home/user/data:/target:ro
    istepanov/backup-to-git
```