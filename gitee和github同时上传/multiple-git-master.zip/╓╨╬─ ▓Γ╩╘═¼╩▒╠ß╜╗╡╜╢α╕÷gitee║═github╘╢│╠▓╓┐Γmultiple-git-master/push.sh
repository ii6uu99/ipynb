git push -u github --all
git push coding --all
git push gitee --all

git push -u github --tags
git push coding --tags
git push gitee --tags