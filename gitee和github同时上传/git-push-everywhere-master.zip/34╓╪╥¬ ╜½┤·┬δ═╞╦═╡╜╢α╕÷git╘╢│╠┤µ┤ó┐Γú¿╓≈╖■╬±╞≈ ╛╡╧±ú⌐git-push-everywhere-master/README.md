# git-push-everywhere

Push to multiple remotes, masters or mirrors at once



## What is it?

git-push-everywhere is a small utility which allows you to push code to multiple
git remote repositories (masters / mirrors) without too much hassle. By default
it pushes current branch and tags.

Primary usage intention for git-push-everywhere is publishing your work after
development milestone has been reached.



## Usage

```sh
# Configure as submodule, so you do not need to install it on all your systems
git submodule add https://github.com/a2o/git-push-everywhere ./git-push-everywhere
git submodule update ./git-push-everywhere

# Run it to create sample config file
./git-push-everywhere/git-push-everywhere

# Configure list of mirrors
edit .git-push-everywhere

# Run it for real
./git-push-everywhere/git-push-everywhere
```



## How does it work?

git-push-everywhere does not need any special git subcommand installed, and it
intended to be run directly from your repository. It assumes you will add it as
git submodule and expects .git-push-everywhere config file to be present one
level higher in the directory hierarchy.

Configuration file .git-push-everywhere is property of your repository and it
should contain two main settings:
* a list of all git remote mirrors that you intend to push to with
* a path to your working copy's root repository, if not placed next to it.
git-push-everywhere.

On initial run, it will create sample config file if it does not exist yet.
It will be created one directory higher than git-push-everywhere is located.

Once config file contains at least one remote, it will start pushing current
branch and tags to configured remote repos.



## Configuration file

### Location

Primarily git-push-everywhere assumes that it is used as git submodule in your
project and that your .git-push-everywhere config file is located at the root
of your working copy, next to .git directory, like this:

```
my-project/.git/config
my-project/.git-push-everywhere
my-project/git-push-everywhere/... (git-push-everywhere submodule)
```

When other placements are required, for example lower in directory tree,
i.e. path/to/subdir/for/git-push-everywhere, you need to:
* place .git-push-everywhere file in your root repository
* and create symlink path/to/subdir/for/git-push-everywhere -> ../../../../.git-push-everywhere



## Caveats

Obviously you need push access to all remote repositories.

You should use one primary remote URI as main development location, and others
as read-only replicas for "just in case". Or, if multiple remotes are used
regularly, you should ensure that pushing to any of them will succeed.



## Future TODO - accepting pull requests :)

* Traverse submodules recursively and apply git-push-everywhere wherever
   .git-push-everywhere is encountered next to .git directory/file.

* Other configuration option: place .git-push-everywhere file as expected by
  git-push-everywhere (one level higher in directory hiearchy) and configure
  path to git root directory in it.
