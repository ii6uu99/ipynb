# https://github.com/danielorn/wslsetup





## 安装

1. 右键点击`install.bat`文件
2. 选择“以管理员身份运行”
3. 等到安装完成
4. 在开始菜单中，启动`Ubuntu 18.04`并开始黑客攻击

## 取消安装

卸载所有内容并从头开始

1. 打开开始菜单，搜索“ Ubuntu 1804”。右键单击并选择“卸载”
2. 删除以下内容
    - `$HOME/bash_logout`
    - `$HOME/bashrc`
    - `$HOME/.profile`
    - `$HOME/.ssh`
    - `$HOME/.bash_config`
    - `$HOME/bin`

- 删除对的任何添加`/c/Windows/System32/drivers/etc/hosts`。（添加放置在警卫内部）：

```
Original content of file (do not remove)
####STARTWSLSETUP
WSL SETUP additins (remove this)
####ENDWSLSETUP
```

# 细节

## 从头开始安装WSL

Windows Linux子系统（此处为WSL）使开发人员可以直接在未经修改的Windows上运行GNU / Linux环境，包括大多数命令行工具，实用程序和应用程序，而不会增加虚拟机的开销。[WSL的官方文件](https://docs.microsoft.com/en-us/windows/wsl/about)

运行时`install.bat`将发生以下情况

1. 该脚本将检查您是否以管理员身份运行。如果没有，它将退出
2. 该脚本将检查您是否已启用Linux的Windows子系统。如果没有，它将启用它并退出（以允许重新启动）。
3. 下载[Ubuntu 1804](https://aka.ms/wsl-ubuntu-1804)
4. 安装Ubuntu 1804
5. 设置环境变量共享`USERNAME`，`USERPROFILE`并`DOCKER_HOST`与wsl和Windows 共享
6. 重新配置wsl以将Windows驱动器直接安装在根目录下（即`/c`，`/d`而不是`/mnt/c`，`/mnt/d`等等）。确切的安装配置可以在[wsl.conf中](https://github.com/danielorn/wslsetup/blob/master/wsl.conf)找到
7. 添加与当前Windows用户具有相同名称和主文件夹的wsl用户。确切的过程可以在[addwinuser.sh中](https://github.com/danielorn/wslsetup/blob/master/addwinuser.sh)找到
8. 将新创建的用户设置为默认用户
9. 执行并安装以下模块
    - [000默认](https://github.com/danielorn/wslsetup/blob/master/modules/000-default/README.md)
    - [010-升级](https://github.com/danielorn/wslsetup/blob/master/modules/010-upgrade/README.md)
    - [101个码头工人](https://github.com/danielorn/wslsetup/blob/master/modules/101-docker/README.md)
    - [102个Kubernetes](https://github.com/danielorn/wslsetup/blob/master/modules/102-kubernetes/README.md)
    - [104吉特](https://github.com/danielorn/wslsetup/blob/master/modules/104-git/README.md)
    - [105ssh](https://github.com/danielorn/wslsetup/blob/master/modules/105-ssh/README.md)
    - [106-Powershell](https://github.com/danielorn/wslsetup/blob/master/modules/106-powershell/README.md)

## 仅安装模块

通过`setup.bat`以管理员身份运行，可以将模块安装到现有的wsl安装中。`setup.bat`只是一个包装`setup.sh`

### 如何使用setup.sh

- 请注意，setup.sh应该以管理员身份运行，以保证全部功能（例如修改Windows主机文件等）

不带任何参数运行setup.sh将安装所有模块。也可以给它一个参数以仅安装一个模块。

```
## Install all modules
./setup.sh

## Install only the java module
./setup.sh modules/100-java
```

- 将以下文件备份到 

    ```
    $HOME/.wslbackup
    ```

    - `$HOME/bash_logout`
    - `$HOME/bashrc`
    - `$HOME/.profile`
    - `$HOME/.ssh`
    - `$HOME/.bash_config`
    - `$HOME/bin`
    - `/c/Windows/System32/drivers/etc/hosts`

- 删除以下文件夹（仅在安装了所有模块的情况下）

    - `$HOME/.bash_config`

- 从中删除先前添加的配置

    - `$HOME/.ssh/config`
    - `/c/Windows/System32/drivers/etc/hosts`

- 安装模块

    - 运行`scripts/`文件夹中的所有脚本
    - 将所有二进制文件从复制`bin/`到`$HOME/bin`
    - 将文件附加`ssh`到`$HOME/.ssh/config`
    - 将主机中的文件追加到`/ c / Windows / System32 / drivers / etc / hosts

## 模块剖析