# 101-docker

## Scripts
- Installs docker cli and docker compose
- Creates wrapper for docker-credential-desktop

## Binaries
none

## Bash config
- Alias `d` for `docker`

## Host entries
none

## SSH config
none

