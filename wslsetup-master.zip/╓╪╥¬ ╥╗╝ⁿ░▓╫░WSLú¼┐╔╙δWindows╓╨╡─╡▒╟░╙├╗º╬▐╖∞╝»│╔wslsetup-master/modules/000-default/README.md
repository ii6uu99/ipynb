# 000-default

## Scripts
- Install common utilities

## Binaries
- `linify` : Converts a windows path to a linux path
- `winify` : Converts a linux path to a windows path

## Bash config
- PS1 prompt showing
	- Current git branch (if any)
	- Current kubernetes context (namespace@cluster)

## Host entries
none

## SSH config
none

