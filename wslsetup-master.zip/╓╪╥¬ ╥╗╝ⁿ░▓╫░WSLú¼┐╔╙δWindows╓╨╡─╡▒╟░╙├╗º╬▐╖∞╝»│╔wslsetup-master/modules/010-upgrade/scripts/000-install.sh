#!/usr/bin/env bash
sudo apt-get upgrade -y