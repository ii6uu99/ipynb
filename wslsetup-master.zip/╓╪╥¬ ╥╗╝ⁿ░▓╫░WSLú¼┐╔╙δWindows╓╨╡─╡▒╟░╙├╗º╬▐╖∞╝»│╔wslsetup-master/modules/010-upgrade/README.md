# 010-upgrade

## Scripts
- Upgrades all packages

## Binaries
none

## Bash config
none

## Host entries
none

## SSH config
none

