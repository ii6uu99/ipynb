# 104-git

## Scripts
- Sets sensible defaults for git config

## Binaries
none

## Bash config
None

## Host entries
none

## SSH config
none

