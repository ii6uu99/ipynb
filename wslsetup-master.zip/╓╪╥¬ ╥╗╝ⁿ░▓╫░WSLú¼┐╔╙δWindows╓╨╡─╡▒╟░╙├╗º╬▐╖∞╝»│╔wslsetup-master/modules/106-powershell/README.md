# 106-powershell

## Scripts
- Installs Powershell

## Binaries
none

## Bash config
None

## Host entries
none

## SSH config
none

