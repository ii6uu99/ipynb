# 102-kubernetes

## Scripts
- Installs kubectl

## Binaries
none

## Bash config
To be written

## Host entries
none

## SSH config
none

