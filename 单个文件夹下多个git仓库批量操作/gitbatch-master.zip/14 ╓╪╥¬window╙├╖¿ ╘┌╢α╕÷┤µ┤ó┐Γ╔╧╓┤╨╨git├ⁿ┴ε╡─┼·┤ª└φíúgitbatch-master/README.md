

https://github.com/lewisliu725/gitbatch



# gitbatch

在多个存储库上执行git命令的批处理。

# Windows的用法

## 先决条件

- 该[GIT客户端](https://git-scm.com/downloads)安装。
- GIT客户端配置正确，这意味着您可以成功运行git命令。

## 脚步

1. 将***gitb.bat***复制到包含多个git存储库的本地文件夹中。

2. 打开一个终端，然后找到该文件夹。

3. 然后，您可以像输入***git***命令一样键入***gitb***命令。

    例如：

    下面的命令将为当前文件夹下的所有代码存储库提取代码并为其重新设置代码。

    ```
    gitb pull --rebase --autostash
    ```

# Linux的用法

所有的步骤都是相同的Windows的步骤，唯一不同的是***gitb.sh***将被用来代替***gitb.bat***。