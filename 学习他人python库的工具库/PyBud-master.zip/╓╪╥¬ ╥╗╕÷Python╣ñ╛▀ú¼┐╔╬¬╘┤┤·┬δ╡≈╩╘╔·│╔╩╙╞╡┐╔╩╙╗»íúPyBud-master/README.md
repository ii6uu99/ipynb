https://github.com/CCExtractor/PyBud





# PyBud

PyBud是一个Python调试和分析工具，可生成分步执行代码的视频。

这是调试以下用法示例的PyBud视频输出！

[![演示版](https://user-images.githubusercontent.com/22671592/72966758-4cffd200-3d85-11ea-9602-2b215a315565.gif)](https://user-images.githubusercontent.com/22671592/72966758-4cffd200-3d85-11ea-9602-2b215a315565.gif)

## 安装

使用包管理器[pip](https://pip.pypa.io/en/stable/)安装PyBud。

```bash
pip install pybud
```

## 使用范例

[![用法_示例](https://user-images.githubusercontent.com/22671592/72948262-4011bd00-3d4a-11ea-86e3-c06b99fde817.gif)](https://user-images.githubusercontent.com/22671592/72948262-4011bd00-3d4a-11ea-86e3-c06b99fde817.gif)

## 用法

一旦安装，运行`pybud --help`将为您提供有关如何使用PyBud的概述。

这是帮助输出：

```bash
$ pybud -h
用法：pybud [-h] [-t] [-d文件] [-f功能[功能...]] [-o文件] [-v [文件]] [-c配置] [-p [文件] ]

一个用于分析和分析功能的Python调试器。由Eastan Giebler创建。

可选参数：
  -h，-- help显示此帮助消息并退出
  -t，--test在一组排序，搜索和类似算法上测试PyBud。为 “ pybud / test / test_logs ”包中的
                         每个函数 输出一个PyBud JSON 。

调试：
  调试python 函数 并生成输出日志。

  -d文件，-调试文件
                        您要调试的Python文件的路径。
  -f FUNCTION [FUNCTION ...]，--function FUNCTION [FUNCTION ...]
                        该功能 在 Python的文件要调试，与你要传递的参数一起。如果不使用参数，则默认为main
                         函数 。示例：'-- function test 2 4 '将调用' test（2,4）'。
  -o FILE，--output FILE
                        可选：写入json日志文件的路径。如果不使用参数，则默认为output.pybud 。
  -v [FILE]，-video [FILE]为程序流程的PyBud调试步骤
                        生成视频渲染。可选：提供输出到的文件路径，
                        mp4是唯一受支持的格式，默认为output.mp4。
  -c CONFIG，-video-cfg CONFIG
                        您要使用的YAML视频配置文件的路径，如果未指定，则将加载默认配置。

解析与分析：
  解析PyBud JSON输出和显示在人类可读的形式。

  -p [FILE]，-parse [FILE]
                        您希望解析为人类可读形式的json日志的路径。如果未指定文件，则默认为output.pybud 。
  -v [FILE]，-video [FILE]为程序流程的PyBud调试步骤
                        生成视频渲染。可选：提供输出到的文件路径，
                        mp4是唯一受支持的格式，默认为output.mp4。
  -c CONFIG，-video-cfg CONFIG
                        您要使用的YAML视频配置文件的路径，如果未指定，则将加载默认配置。$ pybud -h
usage: pybud [-h] [-t] [-d FILE] [-f FUNCTION [FUNCTION ...]] [-o FILE] [-v [FILE]] [-c CONFIG] [-p [FILE]]

A Python debugger for analyzing and profiling functions. Created by Eastan Giebler.

optional arguments:
  -h, --help            show this help message and exit
  -t, --test            Test PyBud on a suite of sorting, searching, and similar algorithms. Outputs a PyBud JSON for each function in the
                        'pybud/test/test_logs' package.

Debugging:
  Debug a python function and generate an output log.

  -d FILE, --debug FILE
                        Path to the Python file you wish to debug.
  -f FUNCTION [FUNCTION ...], --function FUNCTION [FUNCTION ...]
                        The function in the Python file you wish to debug, along with the arguments you wish to pass. Defaults to the main
                        function if argument not used. EXAMPLE: '--function test 2 4' will call 'test(2,4)'.
  -o FILE, --output FILE
                        Optional: Path to write the json log file to. Defaults to output.pybud if argument not used.
  -v [FILE], --video [FILE]
                        Generate a video rendering for the PyBud debug steps of the program flow. Optional: provide a filepath to output to,
                        mp4 is the only supported format, defaults to output.mp4.
  -c CONFIG, --video-cfg CONFIG
                        Path to the YAML video config file you wish to use, default configuration will be loaded if not specified.

Parsing and Analysis:
  Parse a PyBud JSON output and display in human-readable form.

  -p [FILE], --parse [FILE]
                        Path to the json log you wish to parse into human-readable form. Defaults to output.pybud if a file is not specified.
  -v [FILE], --video [FILE]
                        Generate a video rendering for the PyBud debug steps of the program flow. Optional: provide a filepath to output to,
                        mp4 is the only supported format, defaults to output.mp4.
  -c CONFIG, --video-cfg CONFIG
                        Path to the YAML video config file you wish to use, default configuration will be loaded if not specified.
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License
[MIT](https://choosealicense.com/licenses/mit/)
