# coding: utf-8

# Python-viewdeps.
#
# by chin@shaftsoft.ru

from parse import parse
from dot import dot
