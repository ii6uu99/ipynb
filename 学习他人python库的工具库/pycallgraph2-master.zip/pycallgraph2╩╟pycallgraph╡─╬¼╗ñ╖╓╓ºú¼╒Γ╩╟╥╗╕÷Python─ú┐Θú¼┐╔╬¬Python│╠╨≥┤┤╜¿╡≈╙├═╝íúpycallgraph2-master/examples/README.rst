Python Call Graph Examples
##########################

Each directory corresponds to the type of output. Make sure you have the appropriate application installed. For example, graphviz will need to be installed to run its examples.

The examples break DRY intentionally so that each source file is self contained and easily parsed visually.

