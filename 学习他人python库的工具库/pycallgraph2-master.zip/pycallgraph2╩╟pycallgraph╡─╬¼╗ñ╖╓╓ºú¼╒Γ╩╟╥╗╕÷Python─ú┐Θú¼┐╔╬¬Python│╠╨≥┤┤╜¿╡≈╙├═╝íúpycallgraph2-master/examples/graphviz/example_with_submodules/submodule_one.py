class SubmoduleOne(object):
    def __init__(self):
        self.one = 1

    def report(self):
        return self.one
