def helper(something):
    return something
