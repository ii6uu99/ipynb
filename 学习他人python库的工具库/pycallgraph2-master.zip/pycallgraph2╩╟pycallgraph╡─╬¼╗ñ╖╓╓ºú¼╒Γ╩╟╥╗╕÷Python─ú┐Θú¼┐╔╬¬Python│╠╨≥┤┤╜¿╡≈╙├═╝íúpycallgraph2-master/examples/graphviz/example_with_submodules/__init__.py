from .example_with_submodules import main

__all__ = [main]
