# A different file to pycallgraph.py because of circular import problem

__version__ = '1.1.3'
__license__ = 'GPLv2'
__author__ = 'Dan Eads'
__url__ = 'https://github.com/daneads/pycallgraph2'
