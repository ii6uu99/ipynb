class PyCallGraphException(Exception):
    pass
