https://github.com/daneads/pycallgraph2



## 快速开始

操作系统依赖性：

- Graphviz是开源软件，可以通过`apt install graphviz`或等效于其他发行版的版本安装在Ubuntu / Debian 上。 [有关更多信息，请参见此处](https://graphviz.org/download/)。

安装容易，因为：

```
pip install pycallgraph2
```

以下示例将graphviz指定为输出程序，因此需要安装它。他们将生成一个名为的文件`pycallgraph.png`。

运行pycallgraph的命令行方法是：

```
$ pycallgraph graphviz -- ./mypythonscript.py
```

API的简单用法是：

```
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput

with PyCallGraph(output=GraphvizOutput()):
    code_to_profile()
```

## 文献资料

叉子的文档正在进行中