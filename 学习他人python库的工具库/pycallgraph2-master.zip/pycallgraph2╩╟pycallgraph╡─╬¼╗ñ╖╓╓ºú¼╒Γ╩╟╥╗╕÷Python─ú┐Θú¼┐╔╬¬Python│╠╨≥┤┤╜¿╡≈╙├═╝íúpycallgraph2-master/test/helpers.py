import time


def wait_100ms():
    time.sleep(0.1)


def wait_200ms():
    time.sleep(0.2)
