def nop():
    pass


def one_nop():
    nop()
