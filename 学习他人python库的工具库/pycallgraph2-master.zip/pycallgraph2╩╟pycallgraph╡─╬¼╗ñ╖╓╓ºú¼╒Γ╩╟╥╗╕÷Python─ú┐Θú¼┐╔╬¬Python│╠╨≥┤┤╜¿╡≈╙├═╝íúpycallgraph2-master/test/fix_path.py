from os import path
import sys

ROOT = path.join(path.abspath(path.dirname(__file__)), '..')
sys.path.insert(0, ROOT)
