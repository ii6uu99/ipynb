# AutoViz

只需一行代码，即可自动可视化任何大小的任何数据集。

AutoViz只需一行即可自动可视化任何数据集。输入任何输入文件（CSV，txt或json），AutoViz将对其可视化。

## 目录

- [安装](https://github.com/AutoViML/AutoViz#install)
- [用法](https://github.com/AutoViML/AutoViz#usage)
- [API](https://github.com/AutoViML/AutoViz#api)
- [维护者](https://github.com/AutoViML/AutoViz#maintainers)
- [贡献](https://github.com/AutoViML/AutoViz#contributing)
- [执照](https://github.com/AutoViML/AutoViz#license)

## 安装

**先决条件**

- [Anaconda](https://docs.anaconda.com/anaconda/install/)

要克隆AutoViz，最好创建一个新环境，并安装所需的依赖项：

要从PyPi安装：

```sh
conda create -n <your_env_name> python=3.7 anaconda
conda activate <your_env_name> # ON WINDOWS: `source activate <your_env_name>`
pip install autoviz
```

要从源代码安装：

```sh
cd <AutoViz_Destination>
git clone git@github.com:AutoViML/AutoViz.git
# or download and unzip https://github.com/AutoViML/AutoViz/archive/master.zip
conda create -n <your_env_name> python=3.7 anaconda
conda activate <your_env_name> # ON WINDOWS: `source activate <your_env_name>`
cd AutoViz
pip install -r requirements.txt
```

## 用法

阅读这篇中型文章以了解如何使用[AutoViz](https://towardsdatascience.com/autoviz-a-new-tool-for-automated-visualization-ec9c1744a6ad)。

在AutoViz目录中，打开Jupyter Notebook，然后使用此行实例化库

```py
from autoviz.AutoViz_Class import AutoViz_Class

AV = AutoViz_Class()
```

将数据集（任何CSV或文本文件）加载到Pandas数据框中，或提供要显示的路径名称和文件名。如果没有文件名，则只需分配文件名参数`""`（空字符串）即可。

使用文件名（或数据框）以及输入中的分隔符和目标变量的名称来调用AutoViz。AutoViz将完成其余的工作。您将在屏幕上看到图表。

```py
filename = ""
sep = ","
dft = AV.AutoViz(
    filename,
    sep,
    target,
    df,
    header=0,
    verbose=0,
    lowess=False,
    chart_format="svg",
    max_rows_analyzed=150000,
    max_cols_analyzed=30,
)
```

这是AV中的主要调用程序。它将调用当前不在AV范围内的所有加载，显示和保存程序。该程序将为输入数据集绘制散点图和其他图，然后使用该`add_plots`函数调用正确的变量名称，并发送该绘图程序创建的图表，例如散点图。您必须确保该`add_plots`函数具有Class AV中定义的变量的确切名称。如果不是，这将产生错误。

**笔记：**

- AutoViz将使用统计有效的样本来可视化任何大小的文件。
- `COMMA`假定为文件中的默认分隔符。但是您可以更改它。
- 假定第一行作为文件头，但是您可以更改它。

## API

**争论**

- `max_rows_analyzed` -限制用于显示图表的最大行数

- `max_cols_analyzed` -限制可以分析的连续变量的数量

- ```
  verbose
  ```

  - 如果为0，则不打印任何消息，并进入静默模式。这是默认值。
  - 如果为1，则在终端上打印消息，并在终端上显示图表。
  - 如果为2，则打印消息但不显示图表，只会保存它们。

## 维护者

- [@AutoViML](https://github.com/AutoViML)
- [@ morenoh149](https://github.com/morenoh149)
- [@hironroy](https://github.com/hironroy)

## 贡献

查看[贡献文件](https://github.com/AutoViML/AutoViz/blob/master/contributing.md)！

公关接受。

## 执照

Apache许可证，版本2.0

## 免责声明

该项目不是Google的官方项目。Google不受它的支持，并且Google特别拒绝对其质量，适销性或特定用途的适用性提供所有担保。