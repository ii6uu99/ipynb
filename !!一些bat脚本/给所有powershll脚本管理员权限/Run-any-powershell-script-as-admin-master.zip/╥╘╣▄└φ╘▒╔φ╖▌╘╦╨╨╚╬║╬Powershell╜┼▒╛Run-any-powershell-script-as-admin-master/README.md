https://github.com/sr3shreya/Run-any-powershell-script-as-admin

# 以管理员身份运行任何Powershell脚本

1. 一键运行具有管理员权限的任何路径下存储的任何powershell脚本。
2. 我们创建一个.bat文件，其中写入以下代码。
3. 只需提及.ps1文件名。
4. 运行以下文件，它将始终在powershell中以管理员权限运行cript.ps1。
5. 确保执行策略设置为“绕过”。
