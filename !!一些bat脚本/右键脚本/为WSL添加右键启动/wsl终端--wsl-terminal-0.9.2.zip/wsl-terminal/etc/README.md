## wsl-terminal.conf

wsl-terminal configure file.

## minttyrc

Mintty configure file.

## themes/

Mintty theme files, [base16-mintty](https://github.com/geoffstokes/base16-mintty).

More theme files:

https://github.com/oumu/mintty-color-schemes

https://github.com/PhilipDaniels/mintty/tree/master/themes
