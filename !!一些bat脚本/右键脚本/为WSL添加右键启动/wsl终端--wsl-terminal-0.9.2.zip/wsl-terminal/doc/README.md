wsl终端
https://github.com/mskyaxl/wsl-terminal
下载地址
https://github.com/mskyaxl/wsl-terminal/releases/tag/v0.9.2

文档

https://mskyaxl.github.io/wsl-terminal/README.zh_CN.html

# wsl终端

用于的Windows子系统为Linux（WSL）的终端模拟器，基于[mintty](http://mintty.github.io/)，[脂肪](https://github.com/paolo-sz/fatty)和[wslbridge2](https://github.com/Biswa96/wslbridge2)。

[英文页面](https://mskyaxl.github.io/wsl-terminal/)

## 截图

![屏幕截图](https://raw.githubusercontent.com/wiki/mskyaxl/wsl-terminal/images/wsl-terminal-3.png)

查看[更多截图](https://github.com/mskyaxl/wsl-terminal/wiki/Screenshots)。

## 用法

1. 从[这里](https://github.com/mskyaxl/wsl-terminal/releases)下载最新版本并解压，或者在`cmd.exe`或WSL里运行`bash -c "wget https://github.com/mskyaxl/wsl-terminal/releases/download/v0.9.0/wsl-terminal-0.9.0.7z && 7z x wsl-terminal-0.9.0.7z"`。
2. 运行`open-wsl.exe`可以在当前目录打开一个WSL终端模拟器（wsl-terminal需要放置在本地的NTFS分区上，[原因](https://github.com/rprichard/wslbridge#building-wslbridge)）。
3. 运行`tools/1-add-open-wsl-terminal-here-menu.js`（[帮助](https://github.com/mskyaxl/wsl-terminal/blob/master/README.zh_CN.md#工具)）添加来一个`Open wsl-terminal Here`右键菜单到资源管理器上（运行`tools/1-remove-open-wsl-terminal-here-menu.js`可以将其删除）。如果你使用总指挥官，参考可以[在总指挥官中使用WSL-终端](https://github.com/mskyaxl/wsl-terminal/wiki/Use-wsl-terminal-with-Total-Commander)。
4. `run-wsl-file.exe`可以在wsl-terminal里运行任何`.sh`（以及任何其他的替换文件，某些文件`.py` `.pl`）脚本文件，你可以在文件打开方式里设置使用它来打开文件。
5. `vim.exe`可以使用WSL中的vim：任何文件（在wsl-terminal中），支持在打开方式中配置。如果您使用其他编辑器，可以把`vim.exe`重命名成 `emacs.exe` `nvim.exe` `nano.exe`等等，会调用对应的编辑器打开。

## 快捷键

| 按键                     | 功能                         |
| ------------------------ | ---------------------------- |
| `Alt` + `Enter`          | 全屏                         |
| `Alt` + `F2`             | 新建玻璃                     |
| `Alt` + `F3`             | 搜索文字                     |
| `Ctrl`+ `[Shift]`+`Tab`  | 切换窗口                     |
| `Ctrl` + `=` `+` `-` `0` | 缩放                         |
| `Ctrl` + `鼠标左键`      | ：光标处的文件，目录名或网址 |
| `Ctrl` + `鼠标右键`      | ：快捷菜单                   |

[将wsl-terminal绑定到快捷键](https://github.com/mskyaxl/wsl-terminal/wiki/Bind-wsl-terminal-to-a-hotkey)。

## 命令行参数

### 打开WSL

```
用法: open-wsl [选项]...
  -a: 激活在运行的 wsl-terminal 窗口。
      如果 use_tmux=1，会 attach 到正在运行的 tmux 会话上。
  -l: 运行一个 login shell 并且切换到家目录（如果 use_tmux=1 则失效）。
  -c command: 运行命令 (例如 -c "echo a b; echo c; cat")。
  -e commands: 运行后边的所有命令 (例如 -e echo a b; echo c; cat)。
  -C dir: 进入到 dir 目录中，WSL 目录（例如 /home/username）。
  -W dir: 进入到 dir 目录中，Windows 目录（例如 c:\Users\username)。
  -d distro: 切换发行版。
  -b "options": 传递额外的选项给 wslbridge。
  -B "options": 传递额外的选项给 mintty。
  -h: 显示帮助信息。
```

`-B`和`-b`后可以添加的选项，请参考[mintty参数](https://github.com/mskyaxl/wsl-terminal/wiki/mintty-params)和[wslbridge2参数](https://github.com/Biswa96/wslbridge2#options)。

### cmdtool（在WSL中运行）

```
用法: cmdtool [选项]...
  wcmd: 使用 cmd.exe /c 运行 Windows 程序。
  wstart: 使用 cmd.exe /c start 运行 Windows 程序。
  wstartex 文件路径|网址: 和 wstart 类似，但使用 WSL 风格的路径。
  update: 检查更新，如果有更新可以直接升级。
  killall: 杀死所有的 WSL 进程。
  install dash: 安装 Cygwin 中的 dash（用于调试）。
  install busybox: 安装 Cygwin 中的 busybox（用于调试）。
```

## 工具

`tools` 目录下的工具：

| 文件名                                      | 功能                                                        |
| ------------------------------------------- | ----------------------------------------------------------- |
| 1-add-open-wsl-terminal-here-menu.js        | 添加`Open wsl-terminal Here`快捷菜单到资源管理器上。        |
| 1-删除-open-wsl-terminal-here-menu.js       | 移除`Open wsl-terminal Here`快捷菜单。                      |
| 2-将wsl-terminal-dir-to-path.js添加         | 将`wsl-terminal`目录添加到`Path`环境变量里。                |
| 2-从path.js删除wsl-terminal-dir-dir         | 从`Path`环境变量中可删除`wsl-terminal`目录。                |
| 3-write-distro-to-config-file.js            | 将所有发行版的guid写入到配置文件`etc/wsl-terminal.conf`中。 |
| 4-create-start-menu-shortcut.js             | 创建一个开始菜单快捷方式，指向`open-wsl -C ~`。             |
| 4-create-start-menu-shortcut-login-shell.js | 创建一个开始菜单快捷方式，指向`open-wsl -l`。               |
| 4-remove-all-start-menu-shortcuts.js        | 删除所有wsl-terminal的开始菜单快捷方式。                    |
| 5-使用vim-menu.js添加打开                   | 添加`Open with vim in wsl-terminal`快捷菜单到资源管理器上。 |
| 5-删除-vim-menu.js                          | 移除`Open with vim in wsl-terminal`快捷菜单。               |
| 6-set-default-shell.bat                     | 设置`etc/wsl-terminal.conf`中的`shell`为WSL中用户的shell。  |

双击`.js`文件即可运行。如果`.js`文件被某个编辑器关联上了，可以修改打开方式为`Microsoft (R) Windows Based Script Host`，或者在`tools `目录运行一个`cmd.exe`，然后用`wscript xxx.js`运行对应文件。

## 配置文件

`etc/wsl-terminal.conf` 是wsl-terminal的配置文件：

```
[config]
title="窗口标题"
shell=/bin/bash
use_tmux=0
;icon=
;distro=
```

`etc/themes/`目录下的是主题文件，[使用主题](https://github.com/mskyaxl/wsl-terminal/wiki/Use-themes)。

`etc/minttyrc`是mintty的配置文件，[mintty帮助](https://github.com/mintty/mintty/wiki/Tips)。

## 升级

在`wsl-terminal`里打开`open-wsl.exe`，然后运行`./cmdtool update` 可以检查wsl-terminal的最新版本然后升级。如果下载速度过慢，可以先使用其他方法从[发布页面](https://github.com/mskyaxl/wsl-terminal/releases)下载`wsl-terminal-v{version}.7z`文件，然后将其放入`wsl-terminal`目录，然后运行`./cmdtool update`。

该工具依赖`wget`和`7z`命令（安装方法。Ubuntu：`apt install wget p7zip-full`，Archlinux：）`pacman -S wget p7zip`。

升级过程不会覆盖配置文件，`etc/wsl-terminal.conf`状语从句：`etc/minttyrc`会被放置到`etc/wsl-terminal.conf.pacnew`状语从句：`etc/minttyrc.pacnew`。后升级`bin`目录会残余一些`.bak`文件，因为这些文件还在运行，不能被删除。下一次升级时，之前会将的`.bak`文件全部删除，你也可以等那些进展退出后手删除那些文件。

## 使用tmux

1. 在WSL里安装tmux。
2. 在`etc/wsl-terminal.conf`中设置`use_tmux=1`。如果版本号低于`0.8.1`，还需要添加`attach_tmux_locally=1`。
3. 添加如下代码到`~/.bashrc`（如果配置的是`shell=/bin/bash`）或者`~/.zshrc`（如果配置的是`shell=/bin/zsh`）：

```
[[ -z "$TMUX" && -n "$USE_TMUX" ]] && {
    [[ -n "$ATTACH_ONLY" ]] && {
        tmux a 2>/dev/null || {
            cd && exec tmux
        }
        exit
    }

    tmux new-window -c "$PWD" 2>/dev/null && exec tmux a
    exec tmux
}
```

然后`open-wsl`就会使用tmux了。

## 切换发行版

使用`open-wsl -d distro`（在`cmd.exe`里运行）来切换发行版：

```
# 列出所有发行版
> wslconfig /l
Legacy (默认)
Ubuntu

# 使用 Ubuntu（会运行 wslconfig /s Ubuntu 然后打开 wsl-terminal）
> open-wsl -d Ubuntu

# Ubuntu 已经是默认的发行版了
> wslconfig /l
Ubuntu (默认)
Legacy
```

如果你不想修改默认的发行版，可以在`etc/wsl-terminal.conf`里设置`distro_guid`：

运行`tools/3-write-distro-to-config-file.js`（[帮助](https://github.com/mskyaxl/wsl-terminal/blob/master/README.zh_CN.md#工具)），然后会有窗口弹出结果：

```
result has been written to ..\etc\wsl-terminal.conf:

;distro=kali-linux

;distro=Ubuntu}

remove the ; before distro_guid to use the distro.
```

可以去掉distro_guid前边的; 来使用对应的发行版。

如果你想通过命令行将distro_guid传递给`open-wsl`：

```
# 将 distro 传递给 wslbridge
> open-wsl -b "--distro Ubuntu"
```

## 链接

[常见问题](https://github.com/mskyaxl/wsl-terminal/wiki/FAQ)

[反馈建议](https://github.com/mskyaxl/wsl-terminal/issues)

[发布页面](https://github.com/mskyaxl/wsl-terminal/releases)

[文档帮助](https://github.com/mskyaxl/wsl-terminal/wiki)

## 编译

确保已经在WSL里安装了这些`wget` `tar` `xz` `gzip` `p7zip`（安装方法。Ubuntu：`apt install wget tar xz-utils gzip p7zip-full`，Archlinux ：）`pacman -S wget tar xz gzip p7zip`。

运行`build.bat`。

## 许可

麻省理工学院