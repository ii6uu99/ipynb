
# 一键禁止流氓软件

## One Click Ban on Rogue Software

![ban1](https://github.com/PIKACHUIM/Pika-BAT-App-BanCert/raw/master/helppng/ban1.png)
### 国产流氓、娱乐软件和不受欢迎的软件屏蔽工具

> 众所周知，现如今的国产软件流氓推广几乎无处不在，让人防不胜防

> 你要没有火眼金睛或者稍有疏忽，各种全家桶绝对会让你抓狂到吐血

> 那么有没有什么一劳永逸的方法，禁止电脑安装这些流氓软件呢？

# 使用限制

1. Vista以上UAC开启

2. 软件要有数字证书

# 使用方法

## 禁用软件

双击【一键屏蔽证书.bat】

## 恢复证书

双击【一键洗白证书.ps1】

### 如果无法恢复

双击【系统证书管理.lnk】

![ban2](https://github.com/PIKACHUIM/Pika-BAT-App-BanCert/raw/master/helppng/ban2.png)

# 特别感谢

源码修改自@sharoue的chinawareblock，基于bat重新修改

# 屏蔽列表
## 侵犯隐私
### 重庆重橙
**屏蔽原因：FlashPlayer侵犯用户隐私推广广告，从未见过如此猖狂恶心的流氓公司**
## 恶意安装
### 安徽 沙巴克
**屏蔽原因：下载器恶意安装流氓软件，国内推广最猖狂的**
![ban3](https://github.com/PIKACHUIM/Pika-BAT-App-BanCert/raw/master/helppng/ban3.png)

## 恶意推广
### 160 驱动人生
**屏蔽原因：篡改主页，篡改注册表，篡改安全软件，静默安装推广软件**
![ban4](https://github.com/PIKACHUIM/Pika-BAT-App-BanCert/raw/master/helppng/ban4.png)

### 功辉全部软件
**屏蔽原因：双核浏览器，从未见过盗版还如此猖狂的公司，厉害厉害**
![ban5](https://github.com/PIKACHUIM/Pika-BAT-App-BanCert/raw/master/helppng/ban5.png)

### 上海展盟软件
**屏蔽原因：全是广告**
![ban6](https://github.com/PIKACHUIM/Pika-BAT-App-BanCert/raw/master/helppng/ban6.png)

### 南京晨曦软件
**屏蔽原因：全是推广**
![ban7](https://github.com/PIKACHUIM/Pika-BAT-App-BanCert/raw/master/helppng/ban7.png)

### 万能全部软件
**屏蔽原因：全是广告，想钱想疯了**

### 2345全部软件
**不解释**
**包括好压，抄袭Winrar，但是好压还不错，如果需要请手动移除2345证书或者提前安装**

### 搜狗全部软件
**不解释**

### 360 全部软件
**不解释**

### 百度全部软件
**不解释**

### 金山全部软件
**不解释**

### 遨游全部软件
**不解释**
