#!/bin/sh

echo "Hello ${USER}. I'm a sh-script!"
echo "You called me with the following command line:"
echo "  '$0' $@"
read -p "Press [ENTER] key to continue..."
