# Batch file to create virtualenv and start python

1. Just change the script name `hello.py` and possibly the virtualenvironment name `my_new_app`
2. And replace the `requirements.txt` file to suit your needs