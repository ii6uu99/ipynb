# clientLauncher

https://github.wuyanzheshui.workers.dev/R4mzy/clientLauncher









Windows批处理脚本，通过执行一个脚本来启动各种游戏客户端。

该.bat脚本旨在作为我的游戏客户端的启动器。为什么？当我希望它们全部启动并更新时，可以使它们变得懒惰。

要使用它，您将需要编辑指向游戏客户端可执行文件的脚本。

------

要将批处理/.bat文件固定到W7 / 8/10中的任务栏：

- 创建.bat文件的快捷方式
- 将快捷方式文件的目标设置为：cmd.exe / C“批处理路径”例如：cmd.exe / C“ C：\ scripts \ clientLauncher.bat”
- 现在，您可以将快捷方式固定在任意位置。感谢Kamil Klimek在SuperUser.com上的回答：[https](https://superuser.com/a/193255) : [//superuser.com/a/193255](https://superuser.com/a/193255)

我包含的快捷方式文件已经采用这种格式，但是它假定默认的脚本目录为C：\ scripts。您应根据自己的需要进行编辑。

------

脚本信息和主页可以在以下位置找到：[http](http://r4mzy.co.za/?p=877) : [//r4mzy.co.za/?p=877](http://r4mzy.co.za/?p=877)

归功于Rob van der Woude的脚本页面：[http](http://www.robvanderwoude.com/)：//www.robvanderwoude.com/