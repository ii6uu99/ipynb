
https://github.com/laclcia/Win-10-automated-setup-helper

How t如何使用

以管理员身份运行文件Master.bat
根据您要安装的内容回答问题
完成后重新启动计算机
简单

（可选）手动阻止广告添加
如果您想要内置广告和跟踪阻止功能，可以将主机文件复制到C:\Windows\System32\drivers\etc并替换Windows原件

关于
这是由laclica制作的，用于自动化Windows机器的首次设置。在Windows 10中获取基本软件并从Windows 10中删除过时的软件

如果您运行的Windows版本早于10，则可以以管理员身份运行installchocolatey.bat和installsoftwares.bat文件来设置Windows，而不会导致win 10崩溃。

请享用