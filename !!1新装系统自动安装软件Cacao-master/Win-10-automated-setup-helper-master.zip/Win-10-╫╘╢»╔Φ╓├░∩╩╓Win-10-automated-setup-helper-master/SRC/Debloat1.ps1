Get-AppxPackage *windowscommunicationsapps* | Remove-AppxPackage;
Get-AppxPackage *getstarted* | Remove-AppxPackage;
Get-AppxPackage *zune* | Remove-AppxPackage;
Get-AppxPackage *windowsmaps* | Remove-AppxPackage;
Get-AppxPackage *bing* | Remove-AppxPackage;
Get-AppxPackage *people* | Remove-AppxPackage;
Get-AppxPackage *windowsphone* | Remove-AppxPackage;
