https://github.com/roppi/WinToolsAutoSetup



# WinToolsAutoSetup

## 在Windows环境中，请使用Powershell和Chocolatey尽可能自动地设置该工具。



安装以下应用程序

### powershell
- chocolatey

### chocolatey
#### basic.config
- chocolatey GUI
- google Chrome
- f.lux
- 7zip
- Atom Editor
- keypirinha
- sumatrapdf
- github desktop
- cmder
- winmerge-jp
- greenshot

1. 在要展开文件夹的位置创建一个文件夹。

    

    将“ WinToolsAutoSetup.bat”下载到在步骤1中创建的文件夹。

    

    执行2中下载的“ WinToolsAutoSetup.bat”。

- 每次都从Github下载Chocolatey文件。 如果不需要下载，请注释掉第33行。
