# my-vscode
my vscode settings

# root directory
windows10 maybe: `C:\Users\user-name\AppData\Roaming\Code`

# Extensions

* [Image preview](https://marketplace.visualstudio.com/items?itemName=kisstkondoros.vscode-gutter-preview)
  - Shows image preview in the gutter and on hover.
* [Trailing Spaces](https://marketplace.visualstudio.com/items?itemName=shardulm94.trailing-spaces)
  - Highlight trailing spaces and delete them in a flash!
* [HTML Preview](https://marketplace.visualstudio.com/items?itemName=tht13.html-preview-vscode)
  - Rightclick a tab of .html file > "Open Preciew(Ctrl+Shift+V)"
* [indent-rainbow](https://marketplace.visualstudio.com/items?itemName=oderwat.indent-rainbow)
  - Makes indentation easier to read
* [Code Runner](https://marketplace.visualstudio.com/items?itemName=formulahendry.code-runner)
  - Run code snippet or code file for multiple languages: C, C++, Java, JavaScript,...
