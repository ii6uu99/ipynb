# https://github.com/wrestrtdr/automated-setups





# automated-setups

Automated-Setups aka One-Click Apps
