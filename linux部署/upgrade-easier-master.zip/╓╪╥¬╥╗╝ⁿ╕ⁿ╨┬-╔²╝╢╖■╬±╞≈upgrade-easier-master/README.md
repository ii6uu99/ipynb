https://github.com/MLWALK3R/upgrade-easier

# 用法

**首选方法**

```bash
curl -s https://raw.githubusercontent.com/MLWALK3R/upgrade-easier/master/update.sh | bash
```

**Curl** Version
```bash
curl -o update.sh  https://raw.githubusercontent.com/MLWALK3R/upgrade-easier/master/update.sh && chmod +x update.sh && ./update.sh
```

**Wget** Version
```bash
wget https://raw.githubusercontent.com/MLWALK3R/upgrade-easier/master/update.sh && chmod +x update.sh && ./update.sh
```
# 更新变得更容易

专为轻松更新Linux服务器而设计。

基于Debian的操作系统

* apt-get update
* apt-get upgrade -y
* apt-get dist-upgrade -y

基于RHEL的操作系统

 yum upgrade -y 

基于ARCH的操作系统

* pacman -Scc --noconfirm
* pacman -Syu --noconfirm

