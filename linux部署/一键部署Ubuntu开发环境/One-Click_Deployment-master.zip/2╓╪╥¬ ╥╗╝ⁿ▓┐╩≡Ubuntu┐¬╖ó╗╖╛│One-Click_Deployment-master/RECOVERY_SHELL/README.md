1. 将 'Fast_Install_Box' 文件夹拷至新刷好Ubuntu系统的任意位置
2. 换Ubuntu软件源（推荐ustc.edu.cn源）
3. bash RECOVERY.sh
