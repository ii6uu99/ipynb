
echo 'apt-get operation'
sudo apt-get update
sudo apt-get upgrade
sudo apt-get -f install
