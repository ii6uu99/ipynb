
echo 'Install chrome'
sudo dpkg -i ../../Chrome_Wall/google-chrome-stable_current_amd64.deb
