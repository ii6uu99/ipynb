
echo 'Decompress SogouPinyin'
sudo dpkg -i ../../Sogou/sogoupinyin_2.1.0.0086_amd64.deb
