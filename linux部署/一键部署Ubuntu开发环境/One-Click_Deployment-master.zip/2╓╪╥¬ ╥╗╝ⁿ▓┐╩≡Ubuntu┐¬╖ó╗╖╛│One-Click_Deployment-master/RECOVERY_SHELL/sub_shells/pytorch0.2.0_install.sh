
echo 'Install PyTroch'
pip install --upgrade ../../PyTorch/torch-0.2.0.post3-cp27-cp27mu-manylinux1_x86_64.whl
pip install torchvision

