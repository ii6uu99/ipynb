
echo 'Install dependencies'
sudo apt-get install libcupti-dev

echo 'Install tensorflow-gpu'
pip install --upgrade ../../Tensorflow/tensorflow_gpu-1.4.0-cp36-cp36m-linux_x86_64.whl
