
echo 'Decompress pycharm'
mkdir ~/Software/Pycharm
sudo tar -zxvf ../../Pycharm/pycharm-community-2017.2.3.tar.gz -C ~/Software/Pycharm

