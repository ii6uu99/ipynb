https://github.com/JNingWei/One-Click_Deployment

一键部署Ubuntu开发环境

## Overview

	One-Click-Deployment/      root directory
	     |
	     +-- RECOVERY_SHELL/      scripts achieve the function
	     |
	     +-- README.md            manual of project
	     |
	     +-- LICENSE.md           license of project

有6个一键式部署脚本可以选择：

- [x] 1. Cuda8
- [x] 2. Anaconda3
- [x] 3. Cudnn
- [x] 4. Pycharm
- [x] 5. Tensorflow-gpu
- [x] 6. OpenCV3

选择所需的任何内容，然后运行相应的bash进行部署。

**注意：**
由于文件大小的限制，此处仅将代码部分上载，而没有相应的软件包。稍后我将把安装包资源上传到网络。

## 用法

1. 使用`cd RECOVERY_SHELL/`发现脚本。
2. 运行相应的bash来部署所需的环境。

## 要求

- 的Ubuntu
- Bash（Ubuntu随附）

