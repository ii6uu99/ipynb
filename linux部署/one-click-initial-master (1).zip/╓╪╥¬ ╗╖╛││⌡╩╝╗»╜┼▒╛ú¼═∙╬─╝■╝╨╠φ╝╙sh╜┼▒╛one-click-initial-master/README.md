https://github.wuyanzheshui.workers.dev/tyronfong/one-click-initial



## 一键初始化

**one-click-initial**是一种环境初始化脚本，可让用户轻松创建初始脚本。您可以使用创建的脚本来初始化新的box env，而不是进行重复的工作。

已经有一些用于Git初始化和Bash env初始化的基本脚本。Wellcome补充/贡献了一些非常有用的脚本。

## 如何添加新的初始模块

1. 在下面创建.sh文件 `./modules`
2. 按照示例脚本`./modules/modele1.sh`来设置脚本内容

## 如何启动初始脚本

1. `chmod +x ./ocinitial.sh`
2. `./ocinitial.sh`