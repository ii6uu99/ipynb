#!/bin/bash


sudo apt install mysql-server -y /
sudo mysql_secure_installation -n echo $password -y -y -y -y


