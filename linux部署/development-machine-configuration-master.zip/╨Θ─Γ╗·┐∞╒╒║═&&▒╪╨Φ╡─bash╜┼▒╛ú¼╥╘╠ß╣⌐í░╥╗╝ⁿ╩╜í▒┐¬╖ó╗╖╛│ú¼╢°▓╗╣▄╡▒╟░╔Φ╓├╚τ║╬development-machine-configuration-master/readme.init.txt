https://github.com/polux0/development-machine-configuration/blob/master/readme.init.txt

创建开发环境虚拟机的步骤-这些步骤是抽象的，仅用于创建概念，但是每个抽象步骤将通过脚本予以支持；

前提条件是创建初始bash脚本，该脚本将能够在当前目录中执行其他脚本。前提条件脚本需要
手动激活（chmod u + x）；
`initial-script.sh`将会启动其他的（必须从当前目录启动）；


脚本需要的软件： 

##sudo apt-get install curl
1. git -> Create git repository for git options?
2. sublime text *note -> Create git repository for sublime text options
3. intelliJIdea - > -||-

