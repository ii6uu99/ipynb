# 生成_SSH_PEM[![建立状态](https://camo.githubusercontent.com/67c32c121bed500ef2d444dd2adda5bd8f2eb1f7/68747470733a2f2f7472617669732d63692e6f72672f6a61636b71742f47656e65726174655f5353485f50454d2e7376673f6272616e63683d6d6173746572)](https://travis-ci.org/jackqt/Generate_SSH_PEM)

一键生成带有身份文件的登录ssh的ssh pem文件，该文件与Amazon EC2实例一样。

这使得系统管理员可以通过指定用户名来运行它，然后它将自动生成ssh私钥/公钥。

生成后，python SimpleHTTPServer将在默认端口（端口：8000）启动。这允许管理员在任何客户端下载ssh私钥。

最后，管理员可以通过ssh命令的**身份文件**登录服务器。

## 先决条件

脚本是在CentOS下开发的，并且*可以*在所有* NX系统下工作。

- 要执行此脚本，需要**root**用户
- 该脚本会将指定的用户名添加到**/ etc**路径的sudoer文件中，因此如果操作系统没有该`/etc/sudoers.d`目录，则可能会失败
- 脚本依赖性`getent`，可从管理数据库获取条目。

## 安装与使用

请用户使用以下命令在* NX系统中下载并执行脚本：

```
wget -O - https://raw.githubusercontent.com/jackqt/Generate_SSH_PEM/master/ssh_private.sh | bash
```

脚本支持命令行选项：

```
$ /path/to/ssh_private.sh -h
Usage: args [-h] [-u username]
-h means help
-u means specify username
```

它可以直接执行，并接收`username`参数以创建系统用户并生成ssh密钥

最后，您将看到以下消息，通知您下载pem文件

```
$ /path/to/ssh_private.sh -u testuser
Copy & Past the below URL into browser to download the private key

	http://192.168.0.2:8000/testuser.pem
	
	http://127.0.0.1:8000/testuser.pem
	
Press Ctrl-c to terminate the web server
Serving HTTP on 0.0.0.0 port 8000 ...
```

对于客户端上的登录远程服务器，请运行带有下载的ssh私钥的命令：

```
ssh -i /path/to/testuser.pem testuser@remote-host
```