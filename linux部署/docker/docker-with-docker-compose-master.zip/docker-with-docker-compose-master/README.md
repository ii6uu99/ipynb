https://github.com/salmanwaheed/docker-with-docker-compose

# Docker与Docker-Compose

**安装**

- 您必须先安装此软件包https://github.com/salmanwaheed/bash-lib

```bash
# after installed bash-lib you can run this command
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/salmanwaheed/docker-with-docker-compose/master/install.sh)"
```

**Uninstall**

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/salmanwaheed/docker-with-docker-compose/master/uninstall.sh)"
```
