#!/bin/bash

set -e

echo "running apt update..."
sudo apt update >/dev/null 2>&1
echo "apt updated!"

if ! $(bash-lib has_pkg docker.io); then
  bash-lib ins_pkg_info docker.io
  sudo usermod -aG docker $USER
  sudo chown -R $USER:$USER /var/run/docker.sock
  echo "$(docker --version)"
else
  echo "docker is already installed in your system!"
fi

if ! $(bash-lib has_pkg docker-compose); then
  URL="https://github.com/docker/compose/releases/download/1.25.5/docker-compose-$(uname -s)-$(uname -m)"
  echo "installing docker-compose... Size: 16.8 MB. It may take time to download and install."
  sudo curl -sL "https://github.com/docker/compose/releases/download/1.25.5/docker-compose-$(uname -s)-$(uname -m)"  -o /usr/bin/docker-compose
  sudo chmod +x /usr/bin/docker-compose
  echo "$(docker-compose --version)"
else
  echo "docker-compose is already installed in your system!"
fi
