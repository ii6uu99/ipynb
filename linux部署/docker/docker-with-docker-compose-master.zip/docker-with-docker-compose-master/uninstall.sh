#!/bin/bash

set -e

bash-lib rm_pkg docker.io
echo "uninstalling docker-compose"
sudo rm -rf /usr/bin/docker-compose && echo "docker-compose has uninstalled!"
