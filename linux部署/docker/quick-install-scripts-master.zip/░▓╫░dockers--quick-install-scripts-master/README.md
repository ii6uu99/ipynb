# quick-install-scripts
shell scripts for installing tools in one click. 

### Docker:

```sh
$ curl -s https://raw.githubusercontent.com/amdadulbari/quick-install-scripts/master/install-docker.sh | sh
```
