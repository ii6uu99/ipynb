

https://github.com/Liupinz/One-click-deployment-pyenv-ubuntu

# One-click-deployment-pyenv-ubuntu

> environment: ubuntu16
## use pyenv-virtualenv
> * pyenv virtualenv 3.5.2 env35 创建一个Python版本为3.5.2的环境,环境叫做env35
> * pyenv activate env35 激活env35这个环境，此时Python版本为3.5.2,且是独立环境
> * pyenv deactivate 离开已经激活的环境
