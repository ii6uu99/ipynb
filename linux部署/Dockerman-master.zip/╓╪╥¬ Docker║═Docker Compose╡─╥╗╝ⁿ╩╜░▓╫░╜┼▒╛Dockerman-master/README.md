https://github.com/hzb/Dockerman#readme



c码头工人

Docker和Docker Compose的一键式安装脚本

### 如何使用

1. 下载 `dockerman.sh`

    ```
    wget https://raw.githubusercontent.com/hzb/Dockerman/master/dockerman.sh
    ```

    要么

    ```
    curl https://raw.githubusercontent.com/hzb/Dockerman/master/dockerman.sh -o dockerman.sh
    ```

2. 运行以下命令

    ```
    chmod +x dockerman.sh
    sudo ./dockerman.sh
    ```