https://github.com/Owez/devconf



# devconf

包含我的常用配置文件，使外观看起来不错

## 它安装什么

它是由为一个的Ubuntu的/ Ubuntu的的的衍生环境（像Xubuntu上的上）和上进行了测试`ubuntu`，`kubuntu`并`linux mint`。运行时会安装以下贴切软件包：

- [python3](https://python.org)
- [VSCodium](https://vscodium.com/)
- [vim](https://en.wikipedia.org/wiki/Vim_(text_editor))
- [htop](https://en.wikipedia.org/wiki/Htop)
- [make](https://en.wikipedia.org/wiki/Make_(software))
- [build-essential](https://packages.debian.org/bullseye/build-essential)
- [wget](https://en.wikipedia.org/wiki/Wget)
- [curl](https://en.wikipedia.org/wiki/CURL)
- [fontconfig](https://en.wikipedia.org/wiki/Fontconfig)
- [zsh](https://en.wikipedia.org/wiki/Z_shell)
- [neofetch](https://github.com/dylanaraps/neofetch)
- [zip](https://packages.debian.org/bullseye/zip)
- [unzip](https://packages.debian.org/buster/unzip)
- [python3](https://en.wikipedia.org/wiki/Python_(programming_language))
- [python3-dev](https://packages.debian.org/bullseye/python3-dev)
- [transmission-gtk](https://en.wikipedia.org/wiki/Transmission_(BitTorrent_client))

- 并且还安装了以下非适当项目：
- [`hack` font](https://sourcefoundry.org/hack/)
- [powerlevel10k zsh theme](https://github.com/romkatv/powerlevel10k)
- [oh-my-zsh (`zsh` plugin manager)](https://ohmyz.sh/)
- [Rust + Cargo (via `rustup`)](https://en.wikipedia.org/wiki/Rust_(programming_language))
- [Jupyter notebook + `nb` zsh alias](https://jupyter.org/)

## Running

简单地运行`./devconf.sh`。这是专门为ubuntu及其衍生版本（linux mint，kubuntu，xubuntu）而制成的，但是（应该）可以在debian上使用。
