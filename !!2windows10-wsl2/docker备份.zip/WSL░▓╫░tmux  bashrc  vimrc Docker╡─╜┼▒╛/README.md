# WSL
Setup script for new WSL system to install tmux / bashrc / vimrc / Docker
