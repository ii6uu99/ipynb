# WSL2-高山实例

我的WSL2 Alpine分发实例的配置

https://github.com/AlexanderAllen/WSL2-Alpine-Instance