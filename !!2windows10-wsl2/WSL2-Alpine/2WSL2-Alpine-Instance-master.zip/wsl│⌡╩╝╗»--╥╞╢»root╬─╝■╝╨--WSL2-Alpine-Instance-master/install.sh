# https://medium.com/@callback.insanity/nuke-and-reinstall-a-wsl-distribution-75f7a4adcdad
#
# 必须以root用户身份运行以下命令，例如（从cmd.exe）：
# wsl --Alpine分发linux--user root

#查看alpine的版本信息
cat /etc/os-release


#启用了国内阿里云源的alpine镜像
cp /etc/apk/repositories /etc/apk/repositories.bak
echo "http://mirrors.aliyun.com/alpine/v3.11/main/" > /etc/apk/repositories
echo "http://mirrors.aliyun.com/alpine/v3.11/community/" >> /etc/apk/repositories

###########
## 国内源--南京大学的
##  /bin/sh -c "sed -i 's#dl-cdn.alpinelinux.org#mirrors.nju.edu.cn#g' /etc/apk/repositories && cat /etc/apk/repositories"
##阿里源  sed -i 's/dl-cdn.alpinelinux.org/mirrors.aliyun.com/g' /etc/apk/repositories
##科大 sed -i 's/dl-cdn.alpinelinux.org/mirrors.ustc.edu.cn/g' /etc/apk/repositories
###########

###设置时区
apk update
apk add curl bash tree tzdata make
cd /usr/share/zoneinfo && ls
cp -r -f /usr/share/zoneinfo/PRC /etc/localtime && echo -ne "Alpine Linux 3.6 image. (`uname -rsv`)\n" >> /root/.built
date

###########

# https://medium.com/@callback.insanity/successfully-connect-alpine-wsl-2-to-docker-desktop-2-2-620e135340df
# 确保您不是从Windows挂载运行此程序
cd /tmp

# 安装先决条件
apk add ca-certificates wget bash vim

# Install https://github.com/sgerrand/alpine-pkg-glibc.
# Docker Desktop needs glibc in order to create Unix socket proxy.

sudo wget -q -O /etc/apk/keys/sgerrand.rsa.pub https://alpine-pkgs.sgerrand.com/sgerrand.rsa.pub
wget https://github.com/sgerrand/alpine-pkg-glibc/releases/download/2.30-r0/glibc-2.30-r0.apk
apk add glibc-2.30-r0.apk

# 安装Docker CLI和Docker Compose
apk add docker-cli docker-compose
