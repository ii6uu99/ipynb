https://github.com/bossm0n5t3r/auto-setup

# 自动设定

此存储库基于[shubhampathak / autosetup](https://github.com/shubhampathak/autosetup)。

auto-setup.sh是一个简单的bash脚本（与基于Debian的发行版（如Ubuntu）兼容），用于在完成全新安装后安装和设置必要的软件/工具。

> 脚本完全基于编程工具以及一些我经常使用的应用程序，例如Visual Studio Code，Chromium等。您可以根据需要进行修改。

## 用法

### Linux（基于Ubuntu的基于Debian的发行版）

```bash
wget https://bit.ly/auto-setup
chmod +x auto-setup
./auto-setup

# After reboot,
bash ~/gitFolders/ubuntu-auto-setup/after-auto-setup.sh
```

> ### Windows 10
>
> > #### 必备工具
>
> - [Git](https://git-scm.com/)
> - [Visual Studio Code](https://code.visualstudio.com/)
> - This repository

```bash
＃配置基本的git安装程序，并在安装后安装Visual Studio Code Extensions 
＃在此存储库文件夹中打开git bash 
＃设置git status并安装vscode扩展名

bash auto-setup.sh
```

## 结构体

它将执行以下操作：

1. 删除Firefox和默认的Vim。
2. 安装vim并将vim设置为默认编辑器。
3. 安装我需要的所有软件包。
4. Python 3.7默认设置
5. 设置点并更新
6. 自定义gsettings。
7. 设置Git全局配置。（它将询问您的姓名和电子邮件）
8. 安装VSCode，Java等。（请参见下面的列表）
9. 克隆我的个人git存储库。

## 清单

- ~~Anaconda~~ (Leave as Comments)
- Bleachbit
- Google Chrome
- D2Coding font
- Java
- LibreOffice
- Telegram
- vim-plug
- Visual Studio Code
- zsh
- My personal git repositories

## 注意

在Ubuntu 19.10上进行了测试，但它也应与其他基于Debian的发行版一起使用。