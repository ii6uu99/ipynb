cd ~/gitee/linux-gitee
cp debian.sh install.sh tool.sh zsh.sh manager.sh ~/github/github-linux
cd ~/github/github-linux/.mirror
./github.sh
#echo 'git commit -am '
code ~/github/github-linux