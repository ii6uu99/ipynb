# 适用于Linux的Windows子系统（Ubuntu 18.x）

## 设置ConEmu终端

1. 下载并安装[ConEmu](https://conemu.github.io/en/Downloads.html)
2. 下载并安装[Powerline Nerd字体](https://github.com/ryanoasis/nerd-fonts/blob/master/patched-fonts/DejaVuSansMono/Regular/complete/DejaVu Sans Mono Nerd Font Complete Mono Windows Compatible.ttf)
3. 转到ConEmu的任务设置，并添加一个名为“ bash-wsl”的任务

- 任务参数

```bash
-icon "%USERPROFILE%\AppData\Local\lxss\bash.ico"
```
- 任务指令
```bash
set "PATH=%ConEmuBaseDir%\wsl;%PATH%" & %ConEmuBaseDir%\conemu-cyg-64.exe --wsl -C~ -cur_console:pm:/mnt```
```

4. 转到ConEmu的环境设置，将PATH更新为
```bash
set PATH=%ConEmuBaseDir%\Scripts;%PATH%
```

5. 转到ConEmu的字体设置，并将“主控制台字体”和“备用字体”都设置为“ DejaVuSansMono Nerd字体”
6. 转到Windows系统上的环境变量并添加新变量
```bash
ConEmuBaseDir=C:\Program Files\ConEmu\ConEmu'
```
（安装ConEmu的路径）（在https://conemu.github.io/en/BashOnWindows.html上了解有关ConEmu上Wsl / Bash的更多信息）



## 设置/配置VIM

1. 安装cmake和python

```bash
  sudo apt-get update
  sudo apt-get install build-essential cmake python python3 python-dev python3-dev
```
- WSL默认没有cmake
- python-dev软件包包含构建python扩展所需的头文件

1. 安装vim-plug

```bash
  curl -fLo ~/.vim/autoload/plug.vim --create-dirs https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim
```
- https://github.com/junegunn/vim-plug

3. Update .vimrc
 ```bash
   wget https://raw.githubusercontent.com/vespaiach/wsl-configuration/master/.vimrc
 ```

4. 安装插件转到vim并运行命令：PlugInstall

##  

## Install tmux
```bash
sudo add-apt-repository ppa:pi-rho/dev
sudo apt-get update
sudo apt-get install tmux-next

# Rename tmux-next to tmux:
sudo mv /usr/bin/tmux-next /usr/bin/tmux
```

## 安装node / npm / yarn

```bash
  curl -sL https://deb.nodesource.com/setup_10.x | sudo -E bash -
  sudo apt-get install -y nodejs
  
  curl -sL https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add -
  echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list
  sudo apt-get update && sudo apt-get install yarn
```
