c.TerminalInteractiveShell.editing_mode = 'vi'
