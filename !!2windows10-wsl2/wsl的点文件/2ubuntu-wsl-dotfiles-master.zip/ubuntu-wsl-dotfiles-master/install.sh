#! /usr/bin/env bash

apt-get update
apt-get upgrade
apt-get install neofetch
rm ~/.bashrc ~/.vimrc ~/.sshrc ~/.toprc
ln -s ./bashrc ~/.bashrc
ln -s ./vimrc ~/.vimrc
ln -s ./sshrc ~/.sshrc
ln -s ./toprc ~/.config/procps/toprc
