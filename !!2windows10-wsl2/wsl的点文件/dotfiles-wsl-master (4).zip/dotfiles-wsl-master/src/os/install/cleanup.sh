#!/bin/bash

print_in_blue "\n   Cleanup\n\n"

gem cleanup
