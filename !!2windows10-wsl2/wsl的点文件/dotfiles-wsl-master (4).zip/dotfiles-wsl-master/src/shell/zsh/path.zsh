# Ruby
export PATH="$HOME/.rbenv/versions/2.5.5/bin:$PATH"
