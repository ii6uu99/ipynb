source $DOTFILES_SHELL/zsh/aliases/aliases.zsh
source $DOTFILES_SHELL/zsh/aliases/git.zsh
