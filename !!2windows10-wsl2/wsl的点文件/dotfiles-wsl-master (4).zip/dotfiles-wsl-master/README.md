

https://github.com/srod/dotfiles-wsl

# 点文件

基于[https://github.com/alrra/dotfiles的](https://github.com/alrra/dotfiles)个人dotfile

## 建立

```
bash -c "$(curl -LsS https://raw.githubusercontent.com/srod/dotfiles-wsl/master/setup.sh)"
```