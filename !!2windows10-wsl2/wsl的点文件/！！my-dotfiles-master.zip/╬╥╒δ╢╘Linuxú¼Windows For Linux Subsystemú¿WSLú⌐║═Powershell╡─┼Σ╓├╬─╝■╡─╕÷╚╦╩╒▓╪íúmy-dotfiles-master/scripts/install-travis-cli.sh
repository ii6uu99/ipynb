#!/usr/bin/env bash

sudo apt update -qq
sudo apt install -y ruby-full
sudo gem install travis
