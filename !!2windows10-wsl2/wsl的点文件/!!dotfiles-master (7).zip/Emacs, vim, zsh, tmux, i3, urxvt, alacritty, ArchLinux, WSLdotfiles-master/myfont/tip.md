安装ttf-symbola

fira code ligature
https://gist.github.com/CanftIn/e385e090bf9e2f06a46595b8cc4a0dcc