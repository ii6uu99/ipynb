https://github.com/CanftIn/dotfiles

# 点文件

[![img](https://camo.githubusercontent.com/e53d8c6f61493a77dfd4b9dad69f58432b176648/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f646f7466696c65732d76312e302d3531396464392e737667)](https://camo.githubusercontent.com/e53d8c6f61493a77dfd4b9dad69f58432b176648/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f646f7466696c65732d76312e302d3531396464392e737667) [![img](https://camo.githubusercontent.com/450be6de69d05077bcdece3ed1ece7b619de0f4c/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f706c6174666f726d2d57696e646f7773253230253743253230417263684c696e75782532302537432532307465726d75782532302537432532305562756e747525323025374325323057534c2d627269676874677265656e2e737667)](https://camo.githubusercontent.com/450be6de69d05077bcdece3ed1ece7b619de0f4c/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f706c6174666f726d2d57696e646f7773253230253743253230417263684c696e75782532302537432532307465726d75782532302537432532305562756e747525323025374325323057534c2d627269676874677265656e2e737667) [![img](https://camo.githubusercontent.com/6b94888c68e31c812b7dc2ae8e7053c2ec5646fe/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f6c616e67756167652d456c69737025323025374325323056696d7363726970742532302537432532305941536e697070657473253230253743253230626173682d6f72616e67652e737667)](https://camo.githubusercontent.com/6b94888c68e31c812b7dc2ae8e7053c2ec5646fe/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f6c616e67756167652d456c69737025323025374325323056696d7363726970742532302537432532305941536e697070657473253230253743253230626173682d6f72616e67652e737667)

[![支持我](https://camo.githubusercontent.com/26516b72afb49b1e2a56e48954bf1d5c14d08e95/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f72742532304d652d2546302539462539322539372d6666363962342e737667)](https://github.com/CanftIn/MyRC/issues/new)

我的Emacs，vim，zsh，tmux，i3，urxvt，alacritty，ArchLinux，WSL，Windows点文件。

**简易版**的https://github.com/CanftIn/MyRC

我的ArchLinux设置会重新生成文件，这主要`private`是关于我对platfroms的私有配置：

`WSL` => Windows子系统linux环境配置，

`termux` => Anroid termux环境配置，

`arch` => ArchLinux环境配置，

`manager.sh`=> https://github.com/keith/dotfiles

等等。

从2020年开始，==>此仓库不仅针对ArchLinux，而且在Windows `spacemacs`和`vimrc`dotfiles 上也能很好地工作。

`spacemacs`私有配置包括`font ligature` `org mode` `language format` `prettify eshell` `prettify code` `yasnippets` `CanftIn-theming`自定义等。

吸血鬼主题`iA Writer Quattro S` `FiraCode Nerd Font` `iA Writer Mono S`默认需要字体。如果需要，请更改文件中的主题字体。

来自[gpakosz / .tmux的](https://github.com/gpakosz/.tmux) tmux配置

来自[CanftIn / i3wm-](https://github.com/CanftIn/i3wm-themer) themer的i3wm配置

从urxvt字体（哈克书呆子字体）[书呆子的字体](https://github.com/ryanoasis/nerd-fonts)

需要安装触摸板设置[libinput-](https://github.com/CanftIn/dotfiles/blob/master/.config/libinput-gestures.conf)`libinput-gestures` gestures.conf以支持客户

```
$ sudo gpasswd -a $USER input  # add user to input user group
$ vim $HOME/.config/libinput-gestures.conf # copy /etc/libinput-gestures.conf
$ libinput-gestures-setup start
```
启用触摸板：
```
$ xinput list
$ xinput list-props "SynPS/2 Synaptics TouchPad" 
$ xinput set-prop "SynPS/2 Synaptics TouchPad"  "libinput Tapping Enabled" 1
```

**关于vimrc：**

*过去：* vimrc主要指[humiaozuzu / dot-vimrc](https://github.com/humiaozuzu/dot-vimrc) && [yangyangwithgnu / use_vim_as_ide](https://github.com/yangyangwithgnu/use_vim_as_ide/blob/master/.vimrc)

*现在：* vimrc向其他更多配置学习，感谢社区。而且它还在不断改善。



重要

### 如何使用：

```bash
git clone https://github.com/CanftIn/dotfiles.git
cd dotfiles
cp -r . ~
```
