source /home/$USER/.config/broot/launcher/bash/br
