The pic of `bg-saved.cfg` move to

https://github.com/CanftIn/MyRC/tree/master/.config/nitrogen/leimu_pic

In this repo, the pics have been deleted.