xinput set-prop 15 306 1
