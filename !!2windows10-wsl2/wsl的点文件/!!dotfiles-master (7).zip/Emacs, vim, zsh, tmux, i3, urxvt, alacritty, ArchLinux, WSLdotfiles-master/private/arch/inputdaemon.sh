ibus-daemon -d
