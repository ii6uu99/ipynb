# Add Go projects bin to PATH
export PATH="$HOME/go/bin:$PATH"
