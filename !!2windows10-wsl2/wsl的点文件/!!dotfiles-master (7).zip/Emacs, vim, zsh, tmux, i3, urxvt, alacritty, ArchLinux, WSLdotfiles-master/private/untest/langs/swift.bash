# Add swiftpm build to path
export PATH=".git/safe/../../.build/debug:$PATH"
