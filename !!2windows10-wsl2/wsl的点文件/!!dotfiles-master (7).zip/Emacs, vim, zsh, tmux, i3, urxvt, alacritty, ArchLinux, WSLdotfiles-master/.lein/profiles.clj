{:user
  {
  :java-cmd "C:\\Program Files\\Java\\jdk1.8.0_241\\bin\\java.exe"
  :plugins [

    ]
   }

  :java-13-source
  {:extra-deps
   {java-sources {:local/root "C:/Program Files/Java/jdk-13.0.2/lib/src.zip"}}}
 }

