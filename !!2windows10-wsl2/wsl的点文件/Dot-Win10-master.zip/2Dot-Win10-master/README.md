https://github.com/theRemix/Dot-Win10



# 点Win10

使用WSL的Win10点文件

## 提供配置

- wsltty
- fish
- asdf
- vim
- tmux

## 安装

```sh
git clone git@github.com:theRemix/Dot-Win10.git ~/.win
```

## 链接

```sh
ln -s ~/.win/vim ~/.vim
ln -s ~/.win/vimrc ~/.vimrc
ln -s ~/.win/tmux.conf ~/.tmux.conf
ln -s ~/.win/fish ~/.config/fish
ln -s ~/.asdf/completions/asdf.fish ~/.win/fish/completions/asdf.fish
```
