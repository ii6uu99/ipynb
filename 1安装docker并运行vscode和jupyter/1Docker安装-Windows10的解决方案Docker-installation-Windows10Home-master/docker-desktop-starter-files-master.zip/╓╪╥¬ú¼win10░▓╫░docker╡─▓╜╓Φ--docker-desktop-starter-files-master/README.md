# Docker-Windows-10-首页

在Windows 10 Home中安装Docker

#### 在YouTube上查看程序

https://www.youtube.com/watch?v=UqfWTPPlmIQ

[![单击此图像以在Youtube上查看](https://camo.githubusercontent.com/c7bee3768070072bf4169f1e3e10f858fe6db7b6/68747470733a2f2f692e696d6775722e636f6d2f44565451526f552e706e67)](https://www.youtube.com/watch?v=UqfWTPPlmIQ)

### 先决条件

-  在BIOS中启用虚拟化
-  活动的互联网连接

### 脚步

1. 下载或克隆此仓库[点击这里](https://github.com/MaxySpark/Docker-Windows-10-Home/archive/master.zip)
2. 解压缩ZIP文件
3. 右键单击该`hyperV.bat`文件，然后***以管理员身份运行\***
4. ***重新启动\***电脑
5. 右键单击该`container.bat`文件，然后***以管理员身份运行\***
6. ***重新启动\***电脑
7. 打开`docker.reg`文件或右键单击并***合并\***（*重新启动后注册表值将自动恢复为其原始值*）
8. 下载Docker桌面安装程序[单击此处](https://download.docker.com/win/stable/Docker for Windows Installer.exe)
9. 安装它
10. Bingo ***Docker***可以使用了

### 注意：在执行第9步之前，请不要忘记运行第7步

参考：[Docker论坛](https://forums.docker.com/t/installing-docker-on-windows-10-home/11722)