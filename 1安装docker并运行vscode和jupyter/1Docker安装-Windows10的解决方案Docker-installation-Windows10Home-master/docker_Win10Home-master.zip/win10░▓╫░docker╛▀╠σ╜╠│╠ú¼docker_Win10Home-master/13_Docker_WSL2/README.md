# Purpose  
Take note of Docker on WSL2 on Windows 10 Home  

# Table of Contents  
[Activate Docker on WSL2 at Windows 10 Home](#activate-docker-on-wsl2-at-windows-10-home)  

[WSL2 Installation Stuffs](#wsl2-installation-stuffs)  

# Activate Docker on WSL2 at Windows 10 Home  
[Windows10 HomeでWSL2を使ってDockerを動かす  Apr 11, 2020](https://qiita.com/Yoshinari-Yamanaka/items/d9351053f2cd86a5e50e)  

## 3 Ways to Chose  
[windows10でDockerを動かす方法は以下3種類](https://qiita.com/Yoshinari-Yamanaka/items/d9351053f2cd86a5e50e#windows10%E3%81%A7docker%E3%82%92%E5%8B%95%E3%81%8B%E3%81%99%E6%96%B9%E6%B3%95%E3%81%AF%E4%BB%A5%E4%B8%8B3%E7%A8%AE%E9%A1%9E)  
* 1 Docker Desktop for Windows (windows10 Proのみ使用可能)
* 2 Docker Toolbox（Virtual Box等を使用）
* 3 WSL2（私はこれを使用しました！）

# WSL2 Installation Stuffs  
[note_Linux/WSL(WindowsSubsystemLinux)](https://github.com/philip-shen/note_Linux/tree/master/WSL(WindowsSubsystemLinux)#03-wsl2-installation-on-Win-10)  


# Troubleshooting


# Reference


* []()
![alt tag]()

# h1 size

## h2 size

### h3 size

#### h4 size

##### h5 size

*strong*strong  
**strong**strong  

> quote  
> quote

- [ ] checklist1
- [x] checklist2

* 1
* 2
* 3

- 1
- 2
- 3
