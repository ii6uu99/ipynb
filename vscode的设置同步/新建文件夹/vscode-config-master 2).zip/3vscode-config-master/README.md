https://github.com/keery/vscode-config

# VSCode人员配置

在每台机器之间共享我的vscode扩展

要安装所有依赖项，请执行 `path/to/myfile/extensions-installer.bat`

**信息**：要查看扩展，请使用此命令`code --list-extensions | xargs -L 1 echo code --install-extension`