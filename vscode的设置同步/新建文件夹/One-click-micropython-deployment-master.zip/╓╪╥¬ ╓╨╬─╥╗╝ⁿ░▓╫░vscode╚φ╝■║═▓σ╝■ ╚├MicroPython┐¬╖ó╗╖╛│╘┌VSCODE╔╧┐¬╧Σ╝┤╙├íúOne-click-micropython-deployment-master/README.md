﻿https://github.com/junhuanchen/One-click-micropython-deployment



## 一键部署 Python3 VSCODE MPFSHELL 脚本

让 MicroPython 开发环境在 VSCODE 上开箱即用。

## 部署软件

- Python3 最新版，自动判断 32 位或 64 位。
- VSCODE 最新版，自动安装中文语言包、Python、Mpfshell 插件。
- 自动配置 Mpfshell ，命令行输入命令 mpfs 即可启动。

## 使用说明

1. 双击 （安装版）没装过的选这个 即可自动下载安装，安装较慢，请耐心等待

2. 安装过程中，不要关闭【命令提示符】窗口

3. 【其他文件不要打开 ！！！】

4. 如安装不成功，就多重试几次吧~

5. 安装过程中，会自动打开vscode，请关闭vscode编辑器，从桌面快捷方式重新打开，以免汉化插件未生效

6. 【一定要解压啊！！！】

7. 如果安全软件弹出提示，请选择允许操作或退出安全软件

9. 【一定给权限啊！！！】