https://github.com/cmvanb/vscode-config



# vscode-config

## 同步按键，片段和设置

```
cd scripts\
symlink-user-dir.bat
```

## 在本地VSCode中安装存储库扩展

```
cd scripts\
install-vscode-extensions.bat
```

## 从本地VSCode更新扩展的存储库列表

```
cd scripts\
get-vscode-extensions.bat
```