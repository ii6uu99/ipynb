https://github.com/hehan-hqu/Right-click-menu-add-anaconda-button

在右键菜单里面添加一个按钮，实现一键打开ananconda,激活环境或者打开jupyter notebook





# 在右键菜单里面添加一个按钮，实现一键打开ananconda并激活环境和打开jupyter notebook
使用方法：

替换 __AnacondaPath__ 为你的anaconda路径，请使用两个斜杠，例如：C:\\ProgramData\\Anaconda3

替换 __ENV__ 为你的环境名，例如： myenv

如果你使用base环境，请移除 '& activate __ENV__' 。

Enjoy!
