# 右键单击Explorer运行Jupter

`jupyter.exe`在Windows资源管理器中将您添加到右键菜单的PowerShell脚本。



https://github.com/jakkaj/RightClickExplorerRunJupyter

## 用法

克隆此仓库。`addjupyter.ps1`从管理命令提示符处运行。

`jupyter.exe`在运行脚本之前，请确保您已进入环境路径。

[![右键菜单中的Jupyter](https://user-images.githubusercontent.com/5225782/36078876-7a6ecdd4-0fd0-11e8-9a5c-4f13b33b6fe7.png)](https://user-images.githubusercontent.com/5225782/36078876-7a6ecdd4-0fd0-11e8-9a5c-4f13b33b6fe7.png)