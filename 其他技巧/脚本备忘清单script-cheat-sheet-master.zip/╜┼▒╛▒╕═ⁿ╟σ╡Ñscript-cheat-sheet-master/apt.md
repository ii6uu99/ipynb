# 如何初始化包

```bash
sudo apt update
sudo apt full-upgrade -y
sudo apt autoremove -y
sudo apt clean
```

# 如何列出已安装的软件包

```bash
apt list --installed
```

# 如何显示软件包

```bash
sudo apt show <package>
```

# 如何清除包装

```bash
sudo apt purge -y <package>
```