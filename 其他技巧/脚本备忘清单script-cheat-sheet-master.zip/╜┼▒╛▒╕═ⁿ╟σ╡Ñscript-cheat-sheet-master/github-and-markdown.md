# 如何在GitHub存储库中进行全文搜索。

```
https://github.com/search?type=Code&q=repo:<organization>/<repository>+in:file+<q>
```

# 如何将Markdown中的图像调整为固定宽度

```html
<img src="https://example.com/sample.png" width="320" />
```

# 如何在拉取请求中显示之前/之后的图像

Before|After
--|--
A comment comes here.|A comment comes here.
![before](https://picsum.photos/1080)|![after](https://picsum.photos/1080)
