# 如何升级pip

```bash
sudo python -m pip install --upgrade pip
```

# 如何列出已安装的软件包

```batch
pip list
```

# 如何列出已安装软件包的位置

```bash
pip show <package>
```

# 如何安装套件

```bash
# Pakcages will be installed deep under %USERPROFILE%
pip install --user --upgrade <package>
```

# 如何卸载软件包

```bash
pip uninstall -y <package>
```