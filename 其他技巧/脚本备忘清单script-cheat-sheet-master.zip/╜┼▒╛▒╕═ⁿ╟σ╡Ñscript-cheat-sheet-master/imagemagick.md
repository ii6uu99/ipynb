# 如何将图像调整为固定宽度

```shell
convert input.png -resize 320x output.png
```

# 如何在图像上添加8px宽度的边框

```shell
convert input.png -border 8 output.png
```

# 如何将透明度转换为白色

```shell
convert input.png -flatten output.png
```

# 如何将图像转换为灰度

```shell
convert input.png -type grayscale output.png
```

# 如何水平合并图像（并排）

```shell
# "-gravity center" vertically center input images.
convert input1.png input2.png input3.png -gravity center +append output.png
```
