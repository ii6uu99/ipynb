# 注意

- `OFS`使用`{ print }`代替时将被忽略`{ print $1,$2,$3... }`。

# 如何修剪每行中的前导和尾随空格

```shell
gawk '{$1=$1};1' input.txt

# in-place
gawk -i inplace '{$1=$1};1' file.txt
```

# 如果第二个字段是foo或bar，如何显示第一，第二和第三字段

```shell
awk -F',' '($2 == "foo") || ($2 == "bar") { OFS=","; print $1,$2,$3 }' input.txt
```
