# 如何在命令行上表示必需和可选参数

* `<required_argument>`
* `[optional_argument]`
* https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap12.html

# Bash/Zsh
## 如何显示别名的定义

```shell
alias <alias-name>
```

## 如何在yyyymmdd-hhmmss中打印日期和时间

```shell
date +%Y%m%d-%H%M%S
```

## 如何从变量中删除第一个或最后一个字符

```shell
s=abc
echo ${s#?} # bc
echo ${s%?} # ab
```

## 如果不存在该如何创建一个文件夹

```shell
folder1=~/foo
[ -e ${folder} ] || mkdir -p ${folder}
```

## 如何重定向标准输出和/或标准错误

```shell
echo hello > /dev/null # redirects stdout only.
echo hello 2> /dev/null # redirects stderr only.
echo hello &> /dev/null # redirects both stdout and stderr.
```

## 如何替换或删除子字符串

```shell
S=old_and_old
echo ${S/old} # deletes the first "old" and shows "_and_old".
echo ${S//old} # deletes all the "old" and shows "_and_".
echo ${S/old/new} # replace the first "old" and shows "new_and_old".
echo ${S//old/new} # replace all the "old" and shows "new_and_new".
```

## 如何创建包含内容的文件

```shell
cat << EOF > sample.txt
aa
bb
cc
EOF
```

## 如何定义数组

```shell
xs1=(aa bb cc)

xs2=(aa
bb
cc
)
```

## 如何遍历数组

```shell
xs=(aa bb cc)
for x in "${xs[@]}"
do
  echo ${x}
done
```

## 如何将相对路径解析为绝对路径

```shell
realpath <file-or-folder>
```

## 如何在两个Mac / Linux上都检测文件的编码

```shell
file -b sample.txt
```

# 如何将一个文件夹作为子文件夹复制到另一个文件夹

```shell
rsync -a src dst # Note that it's not "/src" but "src"
```

# 如何仅将一个文件夹的内容复制到另一个文件夹

```shell
# Note "src/", not "src"
rsync -a src dst
```

# 如何将多行转换为单行

```shell
$ cat input.txt
aa
bb
cc

$ paste -s -d, input.txt
aa,bb,cc
```

# 如何在不使用匹配列的情况下水平合并文件

```shell
$ cat left.txt
aa
bb

$ cat right.txt
xx
yy

$ paste -d, left.txt right.txt
aa,xx
bb,yy

$ paste -d'\0' left.txt right.txt
aaxx
bbyy
```

# 如何在不使用匹配列的情况下水平连接排除不匹配行的文件

 

* `-t` 是一个分隔符
* `-1` 是来自第一个输入文件的匹配列的基于索引的索引。
* `-2` 是第二个输入文件中匹配列的从一开始的索引。
```shell
$ cat foo.txt
1,aa
2,bb
4,cc

$ cat bar.txt
1,xx
2,yy
5,zz

$ join -t, -1 1 -2 2 foo.txt bar.txt
1,aa,xx
2,bb,yy
````

# 杂项表

```shell
#杀死找到的进程 
ps aux | grep "my_process_name" | awk '{ print $2 }' | xargs kill

#检查命令是否存在
command -v foo > /dev/null 2>&1 || echo 'command not found.'

#one liner
true && { echo 'true1'; echo 'true2'; } || { echo 'false1'; echo 'false2'; }
false && { echo 'true1'; echo 'true2'; } || { echo 'false1'; echo 'false2'; }

# 变化时间戳 
touch -d '2011/03/11' foo.txt

# 三通两个输出和错误 
./foo.sh 2>&1 | tee -a foo.log

# 如果未设置，则设置JAVA_HOME 
[ -z ${JAVA_HOME} ] && export JAVA_HOME=/path/to/javahome

#如果未设置JAVA_HOME，请使用DEFAULT_JAVA_HOME
DEFAULT_JAVA_HOME=/path/to/javahome
${JAVA_HOME=${DEFAULT_JAVA_HOME}} yourclassfile

#在yyyyymmdd 
stat -c %y ${FILE1} | awk '{print $1}' | tr -d '-'


#解压targz文件
tar fvxz foo.tar.gz -C /path/to/destination file_in_targz > /dev/null
```

# 正则表达式

## 如何检查是否`${s}`匹配`${regex}`

```shell
## '=~' is to enable regex in 'if' statement. http://tldp.org/LDP/abs/html/special-chars.html
[[ ${s} =~ ${regex} ]] && echo "matched" || echo "unmatched"
```

## 如何检查是否`${digits}`为数字

```shell
[[ ${digits} =~ ^[[:digit:]]+$ ]] && echo "matched" || echo "unmatched"
```

# 路径备忘单

```shell
echo 'original:' ${s}

echo 'dirname (#1) :' ${s%/*}
echo 'dirname (#2) :' $(dirname ${s})
echo 'filename without dir (#1) :' ${s##*/}
echo 'filename without dir (#2) :' $(basename ${s})
echo 'filename without extension :' $(basename ${s} .${s##*.})
echo 'fullpath without extension :' ${s%.*}
echo 'extname: ' ${s##*.}

echo 'fullpath: ' $(readlink -f ./../relative/path/to/foo.txt)

echo 'script dir as relative path: ' ${0%/*}
echo 'script dir as absolute path: ' $(cd ${0%/*} && pwd && cd - > /dev/null)
```

* # 参考资料

    - [Google Shell样式指南](https://google.github.io/styleguide/shellguide.html)
    - [不推荐使用的Linux联网命令及其替换](https://www.tecmint.com/deprecated-linux-networking-commands-and-their-replacements)

* https://www.tecmint.com/deprecated-linux-networking-commands-and-their-replacements)
