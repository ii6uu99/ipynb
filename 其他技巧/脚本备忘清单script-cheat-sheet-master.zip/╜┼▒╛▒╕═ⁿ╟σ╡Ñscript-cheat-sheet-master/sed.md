* # 注意

    - `-i` 是就地编辑文件，而不是打印到标准输出。
    - `g` 在每一行中启用多个替换。

# 如何更换字符串

```shell
sed "s/old/new/g" input.txt

# in-place
sed -i "s/old/new/g" file.txt
```

# 如何删除空白行，包括仅空白行

```shell
sed -e '/^[[:blank:]]*$/d' input.txt

# in-place
sed -i -e '/^[[:blank:]]*$/d' file.txt
```

## 如何删除空白行而不删除仅空白行

```shell
sed -e '/^$/d' input.txt

# in-place
sed -i -e '/^$/d' file.txt
```

# 如何删除文件中的字符串

```shell
sed "s/unwanted//g" input.txt

# in-place
sed -i "s/unwanted//g" file.txt
```

# 如何给行加上前缀

```shell
sed 's/^/prefix/' input.txt

# in-place
sed -i 's/^/prefix/' file.txt
```

# 如何给行加后缀

```shell
sed "s/$/suffix/" input.txt

# in-place
sed -i "s/$/suffix/" file.txt
```

# 如何显示8位数字，例如yyyymmdd

```shell
sed -e 's/.*\([[:digit:]]\{8\}\).*/\1/g' input.txt
```

# 如何显示双斜杠注释

```shell
sed -e "s/.*\/\/[[:blank:]]*\([^[:blank:]]*\)[[:blank:]]*/\1/g" input.txt
```
