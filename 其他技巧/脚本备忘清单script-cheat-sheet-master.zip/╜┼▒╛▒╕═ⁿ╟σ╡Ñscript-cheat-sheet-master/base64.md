## 如何在base64中编码字符串

```shell
cat input.txt | base64

# Alternatively
echo <plain-string> | base64
```

## 如何在base64中解码字符串

```shell
cat encoded.txt | base64 -d

# Alternatively
echo <encoded-string> | base64 -d
```
