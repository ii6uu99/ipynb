# 如何使用HTTP HEAD方法

```bash
curl --head https://example.com
```

# 如何使用HTTP TRACE方法

```bash
curl -i -X TRACE https://example.com
```

# 如何使用HTTP OPTIONS方法。没有-i，将不会打印任何内容。

```bash
curl -i -X OPTIONS https://example.com
```

# 如何打印http_code

```bash
curl -s -o /dev/null -w "%{http_code}\n" https://example.com
```

# 如何将文件下载到特定目录

```bash
cd <dir> && { curl -O https://example.com/sample.txt; cd -; }

# Alternatively using a subshell
(cd <dir> && curl -O https://example.com/sample.txt )
```

# 如何下载文件并更改文件名。

```bash
curl -o my-favorite-name.txt https://example.com/sample.txt
```

# 如何将文件放入URL

```shell
curl -T sample.jpg https://example.com
```

# 如何将JSON发布到URL（如何发送Firebase Cloud Messaging（FCM）的消息）

```shell
curl 'https://fcm.googleapis.com/fcm/send' \
--header 'Content-Type: application/json' \
--header 'Authorization: key=<server key a.k.a. API key>' \
--data-raw '{
  "priority": 2,
  "registration_ids": [
    "<firebase token>"
  ],
  "data": {
    "foo": "<fill me>",
    "bar": "<fill me>",
  },
  "notification": {
    "title": "<fill me>",
    "body": "<fill me>",
    "click_action": "<fill me>"
  }
}'
```

# 如何使用TinyPNG / TinyJPG压缩PNG或JPG

```shell
curl -i -u api:<api-key> --data-binary @input.png https://api.tinify.com/shrink
```

# 参考资料

# https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods