# 如何升级NPM

```bash
npm install npm@latest -g
```

# 如何列出配置

```bash
npm config list
```

# 如何显示`node_modules`文件夹

```bash
# global
npm root -g

# local
npm root
```

# 如何列出已安装的软件包

```bash
# global
npm ls --depth 0 -g

# local
npm ls --depth 0
```

# 如何更新已安装的软件包

```bash
# global
npm update -g

# local
npm update
```

# 如何在本地安装软件包并将其添加到 `devDependencies`

```bash
npm install <package> --save-dev 
```
* `devDependencies` 是针对开发人员而非用户的。
* `devDependencies`用户安装时不会安装in的软件包`npm install <package>`。
* 您无法全局安装软件包并将其添加到 `devDependencies`

# 如何卸载全局软件包

```bash
npm uninstall <package> -g
```

# 如何卸载本地软件包并将其从中删除 `devDependencies`

```bash
npm uninstall <package> --save-dev
```

# 如何安装作用域包

```bash
npm install @scope/project
```
* * 以@符号`@username/package`开头的包，例如作用域包。
      - 范围使您可以创建与另一个用户或组织创建的包同名的包，在Node.js中通常将其称为“组织”，而不会发生冲突。
      - https://docs.npmjs.com/about-scopes
      - https://docs.npmjs.com/misc/scope

# 如何建立 `package.json``

```bash
npm init -y
```

# 如何在本地包中运行可执行文件

```bash
npx <executable> # e.g. npx tsc foo.ts
```

> 提示：如果您使用的是npm 5.2或更高版本，建议您使用npx全局运行软件包。 https://docs.npmjs.com/downloading-and-installing-packages-globally

# 如何在Visual Studio Code中使用ESLint

 

1. `npm init -y`
2. `npm install eslint eslint-config-google --save-dev`
3. `code .`

# 如何在Visual Studio Code中使用Puppeteer

 

1. `npm init -y`
2. `npm install eslint eslint-config-google puppeteer --save-dev`
3. `code .`

# 注意

- ```
    --save
    ```

     自npm 5以来一直是默认行为。

    - https://blog.npmjs.org/post/161081169345/v500