# 主目录

```batch
%LOCALAPPDATA%\Lxss\home\<username>
```

# 如何从命令提示符处调用WSL命令

```bash
wsl <wsl command>

# Example
wsl ls
```

# References
[WSL Command Reference](https://docs.microsoft.com/en-us/windows/wsl/reference)
