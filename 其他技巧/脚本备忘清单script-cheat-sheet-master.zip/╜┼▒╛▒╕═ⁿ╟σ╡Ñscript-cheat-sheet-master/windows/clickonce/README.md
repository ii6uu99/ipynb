# Note
* ClickOnce VSTO developers need to run `enable-me-to-update-clickonce-app-i-publish.reg` after installing their ClickOnce VSTO application on their computers for the first time. Otherwise, trying to update the application, they will get the "The customization cannot be installed because another version is currently installed and cannot be upgraded from this location." error.

# References
* [Prompt to Manually Uninstall Appears When You Publish and Install a Solution on the Development Computer](https://docs.microsoft.com/en-us/visualstudio/vsto/troubleshooting-office-solution-deployment#prompt-to-manually-uninstall-appears-when-you-publish-and-install-a-solution-on-the-development-computer)