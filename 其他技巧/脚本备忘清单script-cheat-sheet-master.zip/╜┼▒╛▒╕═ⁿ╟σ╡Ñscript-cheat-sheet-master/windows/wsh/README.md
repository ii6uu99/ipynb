Property|Description
---|---
WScript.ScriptFullName| 脚本的绝对路径 
WScript.Script|脚本名称