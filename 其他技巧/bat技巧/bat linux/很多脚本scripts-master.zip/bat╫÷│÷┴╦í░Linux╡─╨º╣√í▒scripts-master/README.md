# 使用方法
复制到Windows文件夹下重开cmd就行。
# 为什么要做
我是一个中学生，用惯了Linux，回到Windows的cmd不习惯，于是我就用批处理做了cat啊，ls啊，wget啊之类的。
仅供娱乐。