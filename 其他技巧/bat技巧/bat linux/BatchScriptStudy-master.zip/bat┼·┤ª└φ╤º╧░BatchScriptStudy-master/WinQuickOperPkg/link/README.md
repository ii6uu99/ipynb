### 常用操作
q.bat 退出cmd  
e.bat 在文件管理器中打开指定目录