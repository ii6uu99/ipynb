# BatchScriptStudy
批处理学习（Windows，Linux）  

学习链接：https://ss64.com/
