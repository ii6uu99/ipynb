# windows_alias
create the windows .bat script likes linux alias ! 
