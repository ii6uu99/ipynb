# WSL Service Manager

I created this to make WSL service easier to control

Feedback is always welcome
