# Need Jupyter Notebooks to open?
The new installation of [Python](https://www.anaconda.com/distribution/#download-section) using **Anaconda** doesn't have *Anaconda Navigator* built in anymore. So running it manually will open it after installing.

This *.bat* file will open Jupyter notebooks where ever you place it.

# How to install

- Make sure you have Jupyter Notebooks or the Latest Version of Python installed. ~3.7^

1. Clone the repo and unzip it 

2. Extract it where you need Jupyter notebooks

3. Double Click / run the file and Jupyter will open and your console will populate with the server status.
