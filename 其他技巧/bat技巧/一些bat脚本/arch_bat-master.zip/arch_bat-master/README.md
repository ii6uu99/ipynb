# arch_bat
---
sideload arch linux along windows using wubi

# Note
---
download the latest wubi installer from https://github.com/hakuna-m/wubiuefi/releases and rename .exe to wubi.exe and place that in 
same directory
- run the bat 
- enter the url of arch linux 

there you go!
