# AnalystWorkbench
A simple .bat script to open various Chrome windows needed for everyday analysis.
