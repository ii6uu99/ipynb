# CmderTools
Extensions and tools to drop into cmder/bin

## pull-request
helper for issuing a pull request from GitHub. Uses the current local branch

usage: pull-request [username] [repository]
